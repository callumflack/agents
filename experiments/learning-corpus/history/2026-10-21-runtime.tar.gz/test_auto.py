"""Quiet context, capture persistence and permission boundaries; native dispatch is checked separately."""
from concurrent.futures import ThreadPoolExecutor
import copy
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import threading
import time
import unittest
from unittest.mock import patch

import learning_auto as auto
from learning_corpus import capture, latest, transcript

OWNER = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("capture_fixtures", OWNER / "test_capture.py")
fixtures = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fixtures)


class QuietTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.corpus = self.root / "Learning"
        self.corpus.mkdir()
        self.source = self.root / "native.jsonl"
        self.request = "Keep upload completion separate from a saved local file."
        self.answer = "The file was saved locally; upload completion remains unverified."
        self.rows = [
            {"type": "session_meta", "payload": {"id": fixtures.SESSION, "cwd": str(self.root)}},
            {"type": "event_msg", "payload": {"type": "task_started", "turn_id": "turn-one"}},
            fixtures.CaptureTests.message("user", self.request, "u1"),
            fixtures.CaptureTests.message("assistant", self.answer, "a1"),
        ]
        self.write_source()
        self.payload = {"hook_event_name": "Stop", "session_id": fixtures.SESSION,
                        "turn_id": "turn-one", "transcript_path": str(self.source)}
        self.selection = fixtures.CaptureTests.selection("saved-before-uploaded", self.request, self.answer)
        self.selection["evidence"]["correction"]["line"] = 3
        self.selection["evidence"]["result"]["line"] = 4

    def write_source(self):
        self.source.write_text("".join(json.dumps(r) + "\n" for r in self.rows))

    def job(self):
        return json.loads(auto.enqueue(dict(self.payload), self.corpus).read_text())

    def assessment(self, selection=None):
        return {"action": "capture", "reason": "The recorded distinction changes what completion means.",
                "covered_case_keys": [], "specs_json": json.dumps([selection or self.selection])}

    def test_capture_is_grounded_readable_repeat_safe_and_preserves_annotations(self):
        (self.corpus / "cases.md").write_text("# Learning cases\n\nHuman annotation: keep this exact sentence.\n")
        job = self.job()
        result = auto.apply_result(job, self.assessment(), self.corpus)
        self.assertEqual(result["status"], "captured")
        self.assertEqual(result["added"], 1)
        readable = (self.corpus / "cases.md").read_text()
        self.assertIn("Human annotation: keep this exact sentence.", readable)
        self.assertIn(self.request, readable)
        self.assertIn(self.answer, readable)
        self.assertIn("1 candidate cases from 1 native chats.", readable)
        self.assertEqual(auto.apply_result(job, self.assessment(), self.corpus)["added"], 0)
        self.assertEqual((self.corpus / "cases.md").read_text(), readable)
        self.assertEqual(latest(self.corpus / "cases.jsonl")[0]["source"]["session_id"], fixtures.SESSION)
        self.assertEqual(len((self.root / "LOG.md").read_text().split("## [")), 2)

    def test_entry_returns_case_context_once_without_ui_message_or_continuation(self):
        auto.apply_result(self.job(), self.assessment(), self.corpus)
        payload = {**self.payload, "hook_event_name": "UserPromptSubmit", "prompt": "Explain upload completion and a saved local file."}
        def entry():
            r = subprocess.run([sys.executable, str(OWNER / "learning_auto.py"), "entry", "--data-dir", str(self.corpus)], input=json.dumps(payload), text=True, capture_output=True)
            self.assertEqual(r.returncode, 0, r.stderr)
            return json.loads(r.stdout)
        context = entry()
        self.assertEqual(set(context), {"hookSpecificOutput"})
        self.assertIn("saved-before-uploaded", context["hookSpecificOutput"]["additionalContext"])
        self.assertNotIn("decision", context)
        self.assertNotIn("systemMessage", context)
        self.assertEqual(entry(), {})

    def test_parallel_tool_entries_supply_only_one_context(self):
        auto.apply_result(self.job(), self.assessment(), self.corpus)
        payload = {**self.payload, "hook_event_name": "PreToolUse"}
        start = threading.Event()
        real_shortlist = auto.shortlist

        def slow_search(*args):
            time.sleep(0.05)
            return real_shortlist(*args)

        def entry(_):
            start.wait()
            return auto.context(dict(payload), self.corpus)

        with patch.object(auto, "shortlist", side_effect=slow_search):
            with ThreadPoolExecutor(max_workers=8) as pool:
                pending = [pool.submit(entry, i) for i in range(8)]
                start.set()
                contexts = [future.result() for future in pending]
        self.assertEqual(sum(bool(result) for result in contexts), 1)

    def test_context_fits_native_delivery_budget_without_cutting_scope_and_receipt_names_only_sent_cases(self):
        originals = {}
        for index in range(3):
            selection = copy.deepcopy(self.selection)
            selection['case_key'] += f'-{index}'
            selection['story']['situation'] = 'Earlier upload work and incidental background. ' * 1000
            selection['learning']['does_not_apply_when'] = [f'Exception {index}: ' + 'Human approval remains necessary for publication. ' * 30]
            auto.apply_result(self.job(), self.assessment(selection), self.corpus)
            originals[selection['case_key']] = selection
        payload = {**self.payload, 'hook_event_name': 'UserPromptSubmit', 'prompt': 'Explain upload completion and a saved local file.'}
        context = auto.context(payload, self.corpus)['hookSpecificOutput']['additionalContext']
        self.assertLessEqual(len(context.encode()), 6000)
        sent = json.loads(context.split('\n', 1)[1])
        self.assertTrue(sent)
        for item in sent:
            self.assertEqual(item['learning']['does_not_apply_when'], originals[item['case_key']]['learning']['does_not_apply_when'])
            self.assertEqual(item['learning']['applies_when'], originals[item['case_key']]['learning']['applies_when'])
        receipt = json.loads((self.corpus / '.runtime/reuse' / f'{fixtures.SESSION}.json').read_text())
        self.assertEqual(receipt['case_keys'], [item['case_key'] for item in sent])

    def test_oversized_scope_cannot_be_silently_cut_or_acknowledged_as_delivered(self):
        self.selection['learning']['does_not_apply_when'] = ['An exception that must survive. ' * 400]
        auto.apply_result(self.job(), self.assessment(), self.corpus)
        payload = {**self.payload, 'hook_event_name': 'UserPromptSubmit', 'prompt': 'Explain upload completion.'}
        with self.assertRaisesRegex(ValueError, 'budget'):
            auto.context(payload, self.corpus)
        self.assertFalse((self.corpus / '.runtime/reuse' / f'{fixtures.SESSION}.json').exists())

    def test_read_only_and_no_write_turns_never_queue_or_create_runtime_state(self):
        for text in ["Read-only: explain upload completion.", "Do not change any files. Explain it.", "No writes. Summarise this.", "Don't edit anything.", "Leave all files unchanged.", "Leave the repository untouched."]:
            self.rows[2] = fixtures.CaptureTests.message("user", text, "u1")
            self.write_source()
            self.assertIsNone(auto.enqueue(dict(self.payload), self.corpus))
        self.assertEqual(list(self.corpus.iterdir()), [])
        self.assertFalse(auto.restricted("Leave the README itself unchanged.", {}))

    def test_skip_creates_no_case_or_readable_receipt(self):
        outcome = auto.apply_result(self.job(), {"action": "skip", "reason": "A routine lookup adds no new distinction.", "covered_case_keys": [], "specs_json": "[]"}, self.corpus)
        self.assertEqual(outcome["status"], "skipped")
        self.assertFalse((self.corpus / "cases.jsonl").exists())
        self.assertFalse((self.corpus / "cases.md").exists())
        self.assertFalse((self.root / "LOG.md").exists())

    def test_bad_quote_and_wrong_turn_fail_without_durable_cases(self):
        job = self.job()
        self.selection["evidence"]["result"]["quote"] = "An invented successful upload."
        with self.assertRaisesRegex(ValueError, "quote matched 0"):
            auto.apply_result(job, self.assessment(), self.corpus)
        self.assertFalse((self.corpus / "cases.jsonl").exists())
        self.selection["evidence"]["result"]["line"] = 99
        self.selection["evidence"]["correction"]["line"] = 98
        with self.assertRaisesRegex(ValueError, "no evidence from the completed task"):
            auto.apply_result(job, self.assessment(), self.corpus)

    def test_delegated_host_request_remains_distinct_from_human_confirmation(self):
        self.rows[2] = {"type": "response_item", "payload": {"type": "function_call_output", "namespace": "codex_app", "name": "send_message_to_thread", "id": "delegated-1", "output": f"<codex_delegation>\n<input>{self.request}</input>\n</codex_delegation>"}}
        self.write_source()
        _, messages = transcript(self.source)
        self.assertEqual(messages[0]["role"], "delegate")
        job = self.job()
        self.selection["evidence"]["correction"]["role"] = "delegate"
        self.selection["story"]["situation"] = "An evaluator-authored delegated task, not a human correction."
        auto.apply_result(job, self.assessment(), self.corpus)
        record = latest(self.corpus / "cases.jsonl")[0]
        self.assertEqual(record["evidence"]["correction"]["role"], "delegate")
        self.selection["outcome"]["basis"] = "user_confirmation"
        with self.assertRaisesRegex(ValueError, "not human confirmation"):
            auto.apply_result(job, self.assessment(), self.corpus)

    def test_install_is_repeat_safe_and_preserves_unrelated_hooks(self):
        path = self.root / "hooks.json"
        unrelated = {"hooks": [{"type": "command", "command": "existing-command"}]}
        path.write_text(json.dumps({"hooks": {"Stop": [unrelated]}}))
        auto.install(path)
        first = path.read_bytes()
        auto.install(path)
        self.assertEqual(path.read_bytes(), first)
        result = json.loads(first)
        self.assertIn(unrelated, result["hooks"]["Stop"])
        self.assertEqual(len(result["hooks"]["Stop"]), 2)

    def test_exhausted_capture_failure_reaches_next_task_once_without_blocking(self):
        inbox = self.corpus / '.runtime/inbox'
        inbox.mkdir(parents=True)
        (inbox / 'auto-failed.json').write_text(json.dumps({'status': 'failed', 'attempts': 3,
            'session_id': fixtures.SESSION, 'error': 'Source evidence could not be validated.'}))
        payload = {**self.payload, 'hook_event_name': 'UserPromptSubmit', 'prompt': 'Draft a note.'}
        result = auto.context(payload, self.corpus)
        self.assertEqual(set(result), {'hookSpecificOutput'})
        self.assertIn('Source evidence could not be validated.', result['hookSpecificOutput']['additionalContext'])
        payload['turn_id'] = 'later-turn'
        self.assertEqual(auto.context(payload, self.corpus), {})


if __name__ == "__main__":
    unittest.main()
