#!/bin/sh
# launchd runs this separately from Codex. Even a missing/crashed Python helper
# takes the OS alert path; healthy checks produce no output or notifications.
set -u
owner_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
state_dir=$1
python_path=$2
mkdir -p "$state_dir" || exit 1
if "$python_path" -B "$owner_dir/learning_watch.py" --state-dir "$state_dir" >"$state_dir/last-run.log" 2>&1; then
    rmdir "$state_dir/runner-alerted" 2>/dev/null || true
else
    if mkdir "$state_dir/runner-alerted" 2>/dev/null; then
        if ! /usr/bin/osascript -e 'display notification "The local learning checker could not run. Ask Codex to inspect it. Your ordinary work can continue." with title "Homebase Learning"'; then
            rmdir "$state_dir/runner-alerted" 2>/dev/null || true
            exit 1
        fi
    fi
fi
