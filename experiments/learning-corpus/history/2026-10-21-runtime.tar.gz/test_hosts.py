"""Native-source preservation and shared-store compatibility across real host formats."""
import json
from pathlib import Path
import tempfile
import unittest

import learning_auto as auto
import learning_hosts as hosts
from learning_corpus import audit, latest, transcript
import test_capture as fixtures


class HostSourceTests(unittest.TestCase):
    def test_native_capture_preserves_host_evidence_and_remains_portable(self):
        for harness in ("pi",):
            with self.subTest(harness=harness), tempfile.TemporaryDirectory() as temp:
                root = Path(temp)
                corpus = root / "Learning"
                corpus.mkdir()
                source = root / "native.jsonl"
                request = "A local backup is incomplete until its linked diagrams can be read offline."
                answer = "Check the actual diagram bytes offline, not only names or cloud metadata."
                rows = [
                    {"type": "session", "id": fixtures.SESSION, "version": 3, "cwd": str(root), "timestamp": "2026-10-20T00:00:00Z"},
                    {"type": "message", "id": "u1", "parentId": None, "timestamp": "2026-10-20T00:01:00Z",
                     "message": {"role": "user", "content": [{"type": "text", "text": request}]}},
                    {"type": "message", "id": "a0", "parentId": "u1", "timestamp": "2026-10-20T00:02:00Z",
                     "message": {"role": "assistant", "stopReason": "toolUse", "content": [{"type": "thinking", "thinking": "Private reasoning."}, {"type": "toolCall", "name": "read"}]}},
                    {"type": "message", "id": "a1", "parentId": "a0", "timestamp": "2026-10-20T00:03:00Z",
                     "message": {"role": "assistant", "stopReason": "stop", "content": [{"type": "thinking", "thinking": "Private reasoning."}, {"type": "text", "text": answer}]}},
                ]
                source.write_text("".join(json.dumps(r) + "\n" for r in rows))
                meta, messages = transcript(source)
                self.assertEqual(meta["harness"], harness)
                self.assertEqual([m["text"] for m in messages], [request, answer])
                payload = {"session_id": fixtures.SESSION, "transcript_path": str(source)}
                path = auto.enqueue(payload, corpus)
                job = json.loads(path.read_text())
                self.assertEqual(job["harness"], harness)
                selection = fixtures.CaptureTests.selection(f"{harness}-offline-assets", request, answer)
                selection["evidence"]["correction"]["line"] = 2
                selection["evidence"]["result"]["line"] = 4
                outcome = auto.apply_result(job, {"action": "capture", "reason": "The bytes are distinct from metadata.",
                    "covered_case_keys": [], "specs_json": json.dumps([selection])}, corpus)
                job.update(outcome)
                auto.atomic(path, job)
                record = latest(corpus / "cases.jsonl")[0]
                self.assertEqual(record["source"]["harness"], harness)
                self.assertEqual(record["source"]["transcript_path"], f"sources/{harness}-{fixtures.SESSION}.jsonl")
                self.assertNotIn("codex://", record["source"]["thread_url"])
                archive = corpus / record["source"]["transcript_path"]
                self.assertNotIn("Private reasoning", archive.read_text())
                self.assertEqual(auto.apply_result(job, {"action": "capture", "reason": "Already saved.",
                    "covered_case_keys": [], "specs_json": json.dumps([selection])}, corpus)["added"], 0)
                source.unlink()
                self.assertEqual(audit(corpus / "cases.jsonl")["verified_revisions"], 1)
                context = hosts.handle("entry", harness, {"prompt": "Explain offline backup diagram bytes."}, corpus)
                rendered = context["context"]
                self.assertIn(record["revision"], rendered)
                self.assertLessEqual(len(rendered), 9000)
                self.assertNotIn("decision", context)

    def test_job_identity_does_not_collide_between_hosts_and_keeps_codex_legacy_identity(self):
        from learning_corpus import digest
        self.assertEqual(auto.job_identity("session", "turn", "answer"), digest(["session", "turn", "answer"]))
        self.assertEqual(len({auto.job_identity("session", "turn", "answer", h) for h in ["codex", "pi"]}), 2)


if __name__ == "__main__":
    unittest.main()
