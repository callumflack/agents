/** Add case context through the existing desktop app-server before delegated turns. */
import { spawn, spawnSync } from 'node:child_process';
import { randomUUID } from 'node:crypto';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const REAL_CLI = '/Applications/ChatGPT.app/Contents/Resources/codex-cli/CodexCLI.app/Contents/MacOS/codex';
const PYTHON = '/opt/homebrew/opt/python@3.14/bin/python3.14';
const HELPER = join(dirname(fileURLToPath(import.meta.url)), 'learning_entry.py');

async function* lines(stream) {
  stream.setEncoding('utf8');
  let pending = '';
  for await (const chunk of stream) {
    pending += chunk;
    let end;
    while ((end = pending.indexOf('\n')) >= 0) {
      yield pending.slice(0, end + 1);
      pending = pending.slice(end + 1);
    }
  }
  if (pending) yield pending;
}

function appServer(args) {
  let index = 0;
  while (index < args.length) {
    const option = args[index];
    if (['-c', '--config', '--enable', '--disable'].includes(option)) index += 2;
    else if (/^(--(?:config|enable|disable)=|-c.)/.test(option) || option === '--strict-config') index++;
    else break;
  }
  return args[index] === 'app-server' && !['daemon', 'proxy', 'generate-ts', 'generate-json-schema', 'help'].includes(args[index + 1]);
}

function delegated(request) {
  const params = request?.params;
  const output = params?.toolOutput;
  return request?.method === 'turn/start' && typeof params?.threadId === 'string' &&
    output?.namespace === 'codex_app' && ['send_message_to_thread', 'create_thread'].includes(output.name) &&
    typeof output.output === 'string' && output.output.startsWith('<codex_delegation>');
}

function helper(action, value) {
  const result = spawnSync(PYTHON, ['-B', HELPER, action], {
    input: JSON.stringify(value), encoding: 'utf8', timeout: 10000,
    maxBuffer: 4 * 1024 * 1024,
  });
  if (result.error) throw result.error;
  if (result.status !== 0) throw new Error(result.stderr.trim() || `Learning helper exited ${result.status}`);
  return JSON.parse(result.stdout);
}

export async function run(command) {
  const intercept = appServer(command.slice(1));
  const child = spawn(command[0], command.slice(1), {
    stdio: intercept ? ['pipe', 'pipe', 'inherit'] : 'inherit',
  });
  const closed = new Promise((resolve, reject) => {
    child.once('error', reject);
    child.once('close', code => resolve(code ?? 1));
  });
  const terminate = signal => child.kill(signal);
  const onTerm = () => terminate('SIGTERM');
  const onInt = () => terminate('SIGINT');
  process.on('SIGTERM', onTerm);
  process.on('SIGINT', onInt);
  try {
    if (!intercept) return await closed;
    const prefix = `homebase-learning-${randomUUID()}-`;
    const waiting = new Map();
    let counter = 0;
    const write = value => new Promise((resolve, reject) => child.stdin.write(value, error => error ? reject(error) : resolve()));
    const responses = (async () => {
      for await (const line of lines(child.stdout)) {
        let response;
        try { response = JSON.parse(line); } catch { /* Native non-JSON output passes through. */ }
        const id = response?.id;
        if (typeof id === 'string' && id.startsWith(prefix)) waiting.get(id)?.(response);
        else process.stdout.write(line);
      }
      for (const resolve of waiting.values()) resolve({ error: { message: 'Native server closed before context acknowledgment' } });
    })();
    const requests = (async () => {
      try {
        for await (const line of lines(process.stdin)) {
          let request;
          try {
            request = JSON.parse(line);
            if (delegated(request)) {
              const prepared = helper('prepare', { request });
              if (prepared) {
                const id = prefix + (++counter);
                let timer;
                const acknowledgment = new Promise((resolve, reject) => {
                  waiting.set(id, resolve);
                  timer = setTimeout(() => reject(new Error('Native context acknowledgment timed out')), 15000);
                });
                try {
                  await write(JSON.stringify({ id, method: 'thread/inject_items', params: {
                    threadId: request.params.threadId,
                    items: [{ type: 'message', role: 'developer', content: [{ type: 'input_text', text: prepared.context }] }],
                  } }) + '\n');
                  const result = await acknowledgment;
                  if (result.error) throw new Error('Native context append failed: ' + JSON.stringify(result.error));
                  helper('ack', { request, prepared });
                } finally {
                  clearTimeout(timer);
                  waiting.delete(id);
                }
              }
            }
          } catch (error) {
            try { helper('error', { request, error: String(error) }); } catch { /* Preserve the native request if diagnostics fail. */ }
          }
          await write(line);
        }
      } catch (error) {
        if (!child.stdin.destroyed) throw error;
      } finally {
        if (!child.stdin.destroyed) child.stdin.end();
      }
    })();
    const code = await closed;
    process.stdin.destroy();
    await Promise.all([responses, requests]);
    return code;
  } finally {
    process.off('SIGTERM', onTerm);
    process.off('SIGINT', onInt);
  }
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  process.exitCode = await run([REAL_CLI, ...process.argv.slice(2)]);
}
