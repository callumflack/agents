#!/usr/bin/env python3
"""Case preparation and receipt helper; never an ancestor of the native app-server."""
import fcntl
import hashlib
import json
from pathlib import Path
import sys

from learning_auto import atomic, candidate_packet, restricted, shortlist, stamp
from learning_corpus import HOMEBASE_ROOT


def delegation(request):
    if not isinstance(request, dict) or request.get('method') != 'turn/start':
        return None
    params = request.get('params', {})
    if not isinstance(params, dict):
        return None
    output = params.get('toolOutput')
    if not isinstance(output, dict):
        return None
    text = output.get('output')
    if (output.get('namespace') != 'codex_app' or
            output.get('name') not in ('send_message_to_thread', 'create_thread') or
            not isinstance(text, str) or not text.startswith('<codex_delegation>') or
            not isinstance(params.get('threadId'), str)):
        return None
    return params['threadId'], text


def main():
    value = json.load(sys.stdin)
    request = value.get('request')
    target = delegation(request)
    corpus = (HOMEBASE_ROOT / 'Learning').resolve()
    if target is None:
        return None
    thread, text = target
    action = sys.argv[1]
    if action == 'prepare':
        cases = shortlist(corpus, text)
        return candidate_packet(cases) if cases else None
    if restricted(text, {}):
        return None
    if action == 'ack':
        prepared = value['prepared']
        folder = corpus / '.runtime' / 'reuse'
        folder.mkdir(parents=True, exist_ok=True, mode=0o700)
        with (folder / f'{thread}.lock').open('a') as lock:
            fcntl.flock(lock, fcntl.LOCK_EX)
            atomic(folder / f'{thread}.json', {
                'request_sha256': hashlib.sha256(text.encode()).hexdigest(),
                'case_keys': prepared['case_keys'], 'case_revisions': prepared['case_revisions'],
                'provided_at': stamp(), 'delivery': 'app-server-before-turn',
                'request_id': request.get('id'),
            })
    elif action == 'error':
        atomic(corpus / '.runtime' / 'auto-error.json', {
            'command': 'preload', 'error': value['error'], 'thread_id': thread,
            'request_id': request.get('id'), 'at': stamp(),
        })
    else:
        raise ValueError('Unknown entry helper action')
    return None


if __name__ == '__main__':
    print(json.dumps(main(), ensure_ascii=False))
