#!/usr/bin/env python3
"""Native Pi lifecycle bridge to the existing quiet reviewer."""
import argparse
import json
import os
from pathlib import Path
import sys

from learning_auto import WORKER_ENV, atomic, candidate_packet, enqueue, restricted, shortlist, stamp, start_drain
from learning_corpus import HOMEBASE_ROOT, transcript


def handle(action, harness, payload, corpus):
    if os.environ.get(WORKER_ENV):
        return {}
    if action == "entry":
        cases = shortlist(corpus, payload.get("prompt", ""))
        value = candidate_packet(cases)["context"] if cases else ""
        pending = corpus / ".runtime/inbox"
        if not restricted(payload.get("prompt", ""), payload) and any(json.loads(p.read_text()).get("status") in ("pending", "failed") and
               json.loads(p.read_text()).get("attempts", 0) < 3 for p in pending.glob("auto-*.json")):
            start_drain(corpus)
        if not value:
            return {}
        return {"context": value}
    meta, _ = transcript(Path(payload["transcript_path"]))
    if meta.get("harness", "codex") != harness:
        raise ValueError("Native lifecycle host disagrees with source")
    payload.pop("turn_id", None)  # The native user message owns turn identity.
    job = enqueue(payload, corpus)
    if job:
        start_drain(corpus)
    return {}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=["entry", "stop"])
    parser.add_argument("harness", choices=["pi"])
    parser.add_argument("--data-dir", type=Path, default=HOMEBASE_ROOT / "Learning")
    args = parser.parse_args()
    corpus = args.data_dir.expanduser().resolve()
    try:
        result = handle(args.action, args.harness, json.load(sys.stdin), corpus)
    except (OSError, ValueError, KeyError, TypeError) as error:
        try:
            atomic(corpus / ".runtime" / f"{args.harness}-error.json", {
                "command": args.action, "harness": args.harness, "error": str(error), "at": stamp()})
        except OSError:
            pass
        result = {}
    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()
