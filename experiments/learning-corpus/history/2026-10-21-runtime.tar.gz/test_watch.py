"""Evidence boundaries: actual native delivery, saved cases, skips and queue time."""
import json
import fcntl
import hashlib
import os
from pathlib import Path
import shutil
import tempfile
import subprocess
import unittest
from unittest.mock import patch

import learning_auto as auto
import learning_watch as watch
from learning_corpus import latest
import test_capture as fixtures

SESSION = fixtures.SESSION


class WatchTests(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name)
        self.corpus = self.root / "Learning"
        self.corpus.mkdir()
        self.source = self.root / "native.jsonl"
        self.prompt = "Keep upload completion separate from a saved local file."
        self.answer = "The file was saved locally; upload completion remains unverified."
        self.rows = [
            {"type": "session_meta", "payload": {"id": SESSION, "cwd": str(self.root)}},
            {"type": "event_msg", "payload": {"type": "task_started", "turn_id": "turn-one"}},
            fixtures.CaptureTests.message("user", self.prompt, "u1"),
            fixtures.CaptureTests.message("assistant", self.answer, "a1"),
        ]
        self.write()
        payload = {"hook_event_name": "Stop", "session_id": SESSION,
                   "turn_id": "turn-one", "transcript_path": str(self.source)}
        self.job_path = auto.enqueue(payload, self.corpus)
        self.job = json.loads(self.job_path.read_text())
        selection = fixtures.CaptureTests.selection("saved-before-uploaded", self.prompt, self.answer)
        selection["evidence"]["correction"]["line"] = 3
        selection["evidence"]["result"]["line"] = 4
        self.job.update(auto.apply_result(self.job, {"action": "capture", "reason": "A meaningful distinction.",
            "covered_case_keys": [], "specs_json": json.dumps([selection])}, self.corpus))
        auto.atomic(self.job_path, self.job)
        self.record = latest(self.corpus / "cases.jsonl")[0]

    def write(self):
        self.source.write_text("".join(json.dumps(r) + "\n" for r in self.rows))

    def task(self):
        return watch.native_tasks(self.source, 0)[0]

    def assess(self, task=None, waiting=(), clock=None):
        task = task or self.task()
        return watch.assess(task, self.corpus, latest(self.corpus / "cases.jsonl"),
                            (self.corpus / "cases.md").read_text(), waiting, 600,
                            clock or task["at"] + 900)[0]

    def test_capture_and_legitimate_skip_are_healthy_but_missing_hook_is_not(self):
        self.assertEqual(self.assess(), [])
        self.job.update(status="skipped", case_keys=[], reason="No new learning.")
        auto.atomic(self.job_path, self.job)
        self.assertEqual(self.assess(), [])
        self.job_path.unlink()
        self.assertEqual([i[0] for i in self.assess()], ["capture"])

    def test_reported_save_needs_real_readable_case_and_source(self):
        (self.corpus / "cases.md").write_text("# Learning cases\n")
        self.assertEqual([i[0] for i in self.assess()], ["capture"])

    def test_human_reconciled_account_needs_its_source_and_exact_witnesses(self):
        page = self.corpus / "cases.md"
        text = page.read_text().replace(f"<!-- learning-auto:{self.record['revision']} -->", "")
        page.write_text(text)
        self.assertEqual(self.assess(), [])
        page.write_text(text.replace(self.answer, "An ungrounded replacement account."))
        self.assertEqual([i[0] for i in self.assess()], ["capture"])

    def test_case_saved_after_request_does_not_create_retrospective_reuse_fault(self):
        self.assertEqual(self.assess(), [])

    def test_receipt_does_not_prove_delivery_but_native_developer_context_does(self):
        for row in self.rows:
            row["timestamp"] = "2099-10-14T12:00:00Z"
        self.write()
        folder = self.corpus / ".runtime/reuse"
        folder.mkdir()
        (folder / f"{SESSION}.json").write_text(json.dumps({"case_keys": [self.record["case_key"]],
            "case_revisions": [self.record["revision"]], "delivery": "app-server-before-turn"}))
        self.assertEqual([i[0] for i in self.assess()], ["reuse"])
        self.rows.insert(1, fixtures.CaptureTests.message("developer", auto.candidate_packet([self.record])["context"], "d1"))
        self.write()
        self.assertEqual(self.assess(), [])
        # A packet arriving after the final answer cannot establish timely delivery.
        self.rows.append(self.rows.pop(1))
        self.write()
        self.assertEqual([i[0] for i in self.assess()], ["reuse"])

    def test_read_only_does_not_require_capture(self):
        self.rows[2]["payload"]["content"][0]["text"] = "Read-only: explain upload."
        self.write()
        self.job_path.unlink()
        self.assertEqual(self.assess(), [])

    def test_native_truncation_wrapper_counts_complete_cases_but_never_partial_or_late_ones(self):
        for row in self.rows:
            row['timestamp'] = '2099-10-14T12:00:00Z'
        context = auto.candidate_packet([self.record])["context"]
        wrapped = 'Warning: truncated output (original token count: 4248)\nTotal output lines: 2\n\n' + context + '\n\nFull hook output saved to: /missing/hook-output.txt'
        self.rows.insert(1, fixtures.CaptureTests.message('developer', wrapped, 'd1'))
        self.write()
        self.assertEqual(self.assess(), [])
        # Keep the real key/revision visible, but destroy the actual case body.
        partial = wrapped[:wrapped.index(', "story"')] + ', ... truncated ...'
        self.rows[1]['payload']['content'][0]['text'] = partial
        self.write()
        self.assertEqual([i[0] for i in self.assess()], ['reuse'])
        self.rows[1]['payload']['content'][0]['text'] = wrapped
        self.rows.append(self.rows.pop(1))
        self.write()
        self.assertEqual([i[0] for i in self.assess()], ['reuse'])

    def test_parser_repair_rechecks_unchanged_native_files_instead_of_reusing_stale_miss(self):
        for row in self.rows:
            row['timestamp'] = '2099-10-14T12:00:00Z'
        self.write()
        missing = self.task()
        context = auto.candidate_packet([self.record])["context"]
        wrapped = 'Warning: truncated output (original token count: 4248)\nTotal output lines: 2\n\n' + context
        self.rows.insert(1, fixtures.CaptureTests.message('developer', wrapped, 'd1'))
        sessions = self.root / 'sessions'
        sessions.mkdir()
        self.source = sessions / 'native.jsonl'
        self.write()
        at = missing['at']
        os.utime(self.source, (at, at))
        stat = self.source.stat()
        previous = {'issues': [('reuse', 'Old parser missed a real wrapped packet.', SESSION, 'turn-one')],
            'files': {str(self.source): {'signature': [stat.st_size, stat.st_mtime_ns], 'tasks': [missing]}}}
        config = {'data_dir': str(self.corpus), 'sessions_dir': str(sessions), 'since': '2000-01-01T00:00:00Z', 'grace_seconds': 600}
        with patch.object(watch, 'configuration', return_value=[]):
            report = watch.scan(config, previous, at + 900)
        self.assertEqual(report['issues'], [])

    def test_compaction_keeps_an_observed_model_exposure_in_its_task_but_does_not_transfer_it(self):
        for row in self.rows:
            row['timestamp'] = '2099-10-14T12:00:00Z'
        self.rows.insert(1, fixtures.CaptureTests.message('developer', auto.candidate_packet([self.record])["context"], 'd1'))
        self.rows.insert(4, {'type': 'response_item', 'payload': {'type': 'reasoning'}})
        self.rows.insert(5, {'type': 'compacted', 'payload': {'replacement_history': []}})
        self.write()
        self.assertEqual(self.assess(), [])
        self.rows += [
            {'type': 'event_msg', 'payload': {'type': 'task_started', 'turn_id': 'turn-two'}},
            fixtures.CaptureTests.message('user', 'Read-only: ' + self.prompt, 'u2'),
            fixtures.CaptureTests.message('assistant', self.answer, 'a2'),
        ]
        self.rows[-2]['timestamp'] = self.rows[-1]['timestamp'] = '2099-10-14T12:02:00Z'
        self.write()
        self.assertEqual([i[0] for i in self.assess(watch.native_tasks(self.source, 0)[1])], ['reuse'])
        # Compaction before any model output must still require a fresh packet.
        self.rows = self.rows[:5] + [self.rows[5], self.rows[6]]
        self.rows.pop(4)
        self.write()
        self.assertEqual([i[0] for i in self.assess()], ['reuse'])

    def test_queue_is_allowed_its_serial_assessment_budget(self):
        self.job.update(status="pending", queued_at="2026-10-14T12:00:00Z")
        auto.atomic(self.job_path, self.job)
        queued = watch.seconds(self.job["queued_at"])
        self.assertEqual(self.assess(waiting=[queued, queued + 1, queued + 2], clock=queued + 1000), [])
        self.assertEqual([i[0] for i in self.assess(waiting=[queued, queued + 1, queued + 2], clock=queued + 1100)], ["capture"])

    def test_completed_task_with_changed_answer_schema_fails_verification(self):
        self.rows[-1]["payload"]["phase"] = "unknown-after-update"
        self.rows.append({"type": "event_msg", "timestamp": "2026-10-14T12:00:00Z",
                          "payload": {"type": "task_complete", "turn_id": "turn-one"}})
        self.write()
        with self.assertRaisesRegex(ValueError, "cannot be interpreted"):
            watch.native_tasks(self.source, 0)

    def test_native_subagent_is_not_a_separate_user_chat(self):
        # Native child logs prepend their own header to inherited parent history.
        parent_header = json.loads(json.dumps(self.rows[0]))
        self.rows[0]["payload"].update(thread_source="subagent", source={"subagent": {"thread_spawn": {"depth": 1}}})
        self.rows.insert(1, parent_header)
        self.rows.append({"type": "event_msg", "timestamp": "2026-10-14T12:00:00Z",
                          "payload": {"type": "task_complete", "turn_id": "child-turn"}})
        self.write()
        self.assertEqual(watch.native_tasks(self.source, 0), [])

    def test_pi_requires_real_timely_system_context_and_its_own_capture_job(self):
        # Pi's system section is a different native transport from Codex's
        # developer messages. A receipt or an earlier removed section is no proof.
        self.rows = [
            {"type": "session", "id": SESSION, "version": 3, "cwd": str(self.root)},
            {"type": "message", "id": "s1", "parentId": None, "message": {"role": "system", "sections": {"homebase_learning": auto.candidate_packet([self.record])["context"]}}},
            {"type": "message", "id": "u1", "parentId": "s1", "timestamp": "2099-10-14T12:00:00Z",
             "message": {"role": "user", "content": self.prompt}},
            {"type": "message", "id": "a1", "parentId": "u1", "timestamp": "2099-10-14T12:01:00Z",
             "message": {"role": "assistant", "stopReason": "stop", "content": [{"type": "text", "text": self.answer}]}},
        ]
        self.write()
        pi_job = auto.enqueue({"session_id": SESSION, "transcript_path": str(self.source)}, self.corpus)
        job = json.loads(pi_job.read_text())
        job.update(status="skipped", reason="Already covered.", case_keys=[])
        auto.atomic(pi_job, job)
        self.assertEqual(self.assess(), [])
        pi_job.unlink()
        # The valid Codex job with the same session must not satisfy Pi capture.
        self.assertEqual([i[0] for i in self.assess()], ["pi-capture"])
        auto.atomic(pi_job, job)
        self.rows[1]["message"]["sections"] = {}
        self.write()
        self.assertEqual([i[0] for i in self.assess()], ["pi-reuse"])
        self.rows[1]["message"]["sections"]["homebase_learning"] = auto.candidate_packet([self.record])["context"]
        self.rows.append(self.rows.pop(1))
        self.write()
        self.assertEqual([i[0] for i in self.assess()], ["pi-reuse"])
        self.rows.insert(1, self.rows.pop())
        self.rows.insert(3, {"type": "message", "id": "a0", "parentId": "u1", "timestamp": "2099-10-14T12:00:10Z",
                           "message": {"role": "assistant", "stopReason": "toolUse", "content": [{"type": "toolCall", "name": "read"}]}})
        self.rows.insert(4, {"type": "compaction", "id": "c1", "parentId": "a0", "timestamp": "2099-10-14T12:00:20Z",
                           "summary": "Work in progress.", "firstKeptEntryId": "u1", "tokensBefore": 10000})
        self.rows[-1]["parentId"] = "c1"
        self.write()
        self.assertEqual(self.assess(), [])
        self.rows += [
            {"type": "message", "id": "u2", "parentId": "a1", "timestamp": "2099-10-14T12:02:00Z",
             "message": {"role": "user", "content": "Read-only: " + self.prompt}},
            {"type": "message", "id": "a2", "parentId": "u2", "timestamp": "2099-10-14T12:03:00Z",
             "message": {"role": "assistant", "stopReason": "stop", "content": self.answer}},
        ]
        self.write()
        self.assertEqual([i[0] for i in self.assess(watch.native_tasks(self.source, 0)[1])], ["pi-reuse"])
        self.rows[4]["systemMessage"] = self.rows[1]["message"]
        self.write()
        self.assertEqual(self.assess(watch.native_tasks(self.source, 0)[1]), [])

    def monitor(self):
        sessions = self.root / "sessions"
        sessions.mkdir()
        source = sessions / "native.jsonl"
        self.source.rename(source)
        self.source = source
        self.job["transcript_path"] = str(source)
        self.job["queued_at"] = "2026-10-14T12:00:00Z"
        auto.atomic(self.job_path, self.job)
        at = self.task()["at"]
        os.utime(source, (at, at))
        state = self.root / "checker"
        state.mkdir()
        config = {"data_dir": str(self.corpus), "sessions_dir": str(sessions),
                  "since": "2000-01-01T00:00:00Z", "grace_seconds": 600}
        auto.atomic(state / "config.json", config)
        return state, at + 900

    def test_checker_resumes_a_failed_capture_and_proves_persistence_without_alerting(self):
        state, clock = self.monitor()
        self.job.update(status="failed", attempts=1, error="Transient assessor failure")
        auto.atomic(self.job_path, self.job)
        (self.corpus / "cases.md").write_text("# Learning cases\n")
        selection = fixtures.CaptureTests.selection("saved-before-uploaded", self.prompt, self.answer)
        selection["evidence"]["correction"]["line"] = 3
        selection["evidence"]["result"]["line"] = 4
        answer = {"action": "capture", "reason": "A meaningful distinction.",
                  "covered_case_keys": [], "specs_json": json.dumps([selection])}
        with patch.object(watch, "configuration", return_value=[]), patch.object(watch.time, "time", return_value=clock), \
                patch.object(watch, "notify") as notice, patch.object(auto, "extract", return_value=answer), \
                patch.object(watch, "start_drain", side_effect=lambda corpus, path: auto.drain(corpus, path), create=True):
            watch.check(state)
            watch.check(state)
        notice.assert_not_called()
        self.assertEqual(json.loads(self.job_path.read_text())["status"], "captured")
        self.assertEqual(json.loads(self.job_path.read_text())["attempts"], 2)
        self.assertIn(self.record["revision"], (self.corpus / "cases.md").read_text())
        self.assertEqual(json.loads((state / "state.json").read_text())["issues"], [])

    def test_checker_exhausts_only_the_existing_capture_budget_then_alerts_once(self):
        state, clock = self.monitor()
        self.job.update(status="failed", attempts=1, error="Assessor unavailable")
        auto.atomic(self.job_path, self.job)
        with patch.object(watch, "configuration", return_value=[]), patch.object(watch.time, "time", return_value=clock), \
                patch.object(watch, "notify") as notice, patch.object(auto, "extract", side_effect=ValueError("Assessor unavailable")), \
                patch.object(watch, "start_drain", side_effect=lambda corpus, path: auto.drain(corpus, path), create=True):
            watch.check(state)
            self.assertEqual(notice.call_count, 0)
            watch.check(state)
            self.assertEqual(notice.call_count, 0)
            watch.check(state)
            watch.check(state)
        self.assertEqual(json.loads(self.job_path.read_text())["attempts"], 3)
        self.assertEqual(notice.call_count, 1)
        report = json.loads((state / "state.json").read_text())
        self.assertEqual(report["notification_count"], 1)
        self.assertIn("three attempts", " ".join(report["repair_errors"].values()))

    def test_busy_worker_is_not_duplicated_and_its_recovery_deadline_cannot_reset(self):
        state, clock = self.monitor()
        self.job.update(status="processing", attempts=1)
        auto.atomic(self.job_path, self.job)
        with (self.corpus / ".runtime/auto-worker.lock").open("a") as lock:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            with patch.object(watch, "configuration", return_value=[]), patch.object(watch.time, "time", return_value=clock) as now, \
                    patch.object(watch, "notify") as notice, patch.object(watch.subprocess, "Popen", side_effect=AssertionError("Duplicate worker")):
                watch.check(state)
                self.assertEqual(notice.call_count, 0)
                now.return_value = clock + 601
                watch.check(state)
                now.return_value = clock + 1202
                watch.check(state)
        self.assertEqual(notice.call_count, 1)
        self.assertEqual(json.loads(self.job_path.read_text())["attempts"], 1)
        self.assertEqual(next(iter(json.loads((state / "state.json").read_text())["recovery"].values()))["status"], "failed")

    def test_missing_recorded_pi_link_waits_for_native_delivery_and_never_replaces_content(self):
        state, clock = self.monitor()
        config = json.loads((state / "config.json").read_text())
        hooks = self.root / "hooks.json"
        auto.atomic(hooks, {"hooks": auto.registration()})
        target, extension = self.root / "pi-learning.ts", self.root / "personal-extension.ts"
        target.write_text("Known installed extension")
        entry = self.root / "entry.json"
        auto.atomic(entry, {k: str(target) for k in ("launcher", "transport_entry", "transport_runtime", "python", "real_cli")})
        pi_sessions = self.root / "pi-sessions"
        pi_sessions.mkdir()
        config.update(hooks_file=str(hooks), entry_install=str(entry), other_hosts=[{
            "harness": "pi", "extension": str(extension), "sessions_dir": str(pi_sessions), "since": config["since"]}], grace_seconds=0)
        auto.atomic(state / "config.json", config)
        receipt = {"pi_extension": {"extension": str(extension), "target": str(target)},
                   "recovery_files": {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in (entry, target)}}
        auto.atomic(state / "install.json", receipt)
        with patch.object(watch.time, "time", return_value=clock) as now, patch.object(watch, "notify") as notice, \
                patch.object(watch.subprocess, "run", return_value=subprocess.CompletedProcess([], 0, str(target), "")):
            watch.check(state)
            self.assertTrue(extension.is_symlink())
            report = json.loads((state / "state.json").read_text())
            self.assertEqual(next(iter(report["recovery"].values()))["status"], "awaiting_delivery")
            watch.check(state)
            self.assertTrue(json.loads((state / "state.json").read_text())["recovery"])
            # A real later Pi format packet, request and final confirm delivery;
            # a restored link alone did not. This request deliberately forbids writes.
            future = "2099-10-14T12:00:00Z"
            rows = [{"type": "session", "id": SESSION, "version": 3, "cwd": str(self.root)},
                {"type": "message", "id": "s1", "message": {"role": "system", "sections": {"homebase_learning": auto.candidate_packet([self.record])["context"]}}},
                {"type": "message", "id": "u1", "timestamp": future, "message": {"role": "user", "content": "Read-only: " + self.prompt}},
                {"type": "message", "id": "a1", "parentId": "u1", "timestamp": future,
                 "message": {"role": "assistant", "stopReason": "stop", "content": self.answer}}]
            source = pi_sessions / "native.jsonl"
            source.write_text("".join(json.dumps(r) + "\n" for r in rows))
            os.utime(source, (watch.seconds(future), watch.seconds(future)))
            now.return_value = watch.seconds(future) + 900
            watch.check(state)
            report = json.loads((state / "state.json").read_text())
            self.assertEqual(report["recovery"], {})
            self.assertEqual(report["repair_results"][0]["status"], "verified")
            notice.assert_not_called()
            # A changed existing extension belongs to its current owner.
            extension.unlink()
            extension.write_text("User-owned replacement")
            prior_issue = ("pi-configuration", "The Pi personal learning extension is missing.", None, None)
            with self.assertRaisesRegex(ValueError, "existing content"):
                watch.connection_repair(prior_issue, config, state)
            self.assertEqual(extension.read_text(), "User-owned replacement")
            extension.unlink()
            target.write_text("Changed after installation")
            with self.assertRaisesRegex(ValueError, "files changed"):
                watch.connection_repair(prior_issue, config, state)
            self.assertFalse(extension.exists())

    def test_codex_only_restores_an_unset_verified_launch_setting(self):
        state, clock = self.monitor()
        launcher = self.root / "launcher"
        launcher.write_text("Original local launcher")
        entry = self.root / "entry.json"
        auto.atomic(entry, {"launcher": str(launcher)})
        config = {"entry_install": str(entry)}
        auto.atomic(state / "install.json", {"recovery_files": {
            str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in (entry, launcher)}})
        issue = ("configuration", "The Codex launch setting no longer selects the learning adapter.", None, None)
        environment = {"CODEX_CLI_PATH": ""}
        def launchctl(command, **kwargs):
            if command[1] == "getenv":
                return subprocess.CompletedProcess(command, 1 if not environment[command[2]] else 0, environment[command[2]], "")
            if command[1] == "setenv":
                environment[command[2]] = command[3]
                return subprocess.CompletedProcess(command, 0, "", "")
            raise AssertionError(command)
        with patch.object(watch.subprocess, "run", side_effect=launchctl):
            self.assertEqual(watch.connection_repair(issue, config, state), "codex")
            self.assertEqual(environment["CODEX_CLI_PATH"], str(launcher))
            environment["CODEX_CLI_PATH"] = "/a/different/user/launcher"
            with self.assertRaisesRegex(ValueError, "another launcher"):
                watch.connection_repair(issue, config, state)
            self.assertEqual(environment["CODEX_CLI_PATH"], "/a/different/user/launcher")
            environment["CODEX_CLI_PATH"] = ""
            launcher.write_text("Changed since installation")
            with self.assertRaisesRegex(ValueError, "files changed"):
                watch.connection_repair(issue, config, state)
            self.assertEqual(environment["CODEX_CLI_PATH"], "")

    def test_targeted_worker_cannot_drain_other_jobs_or_an_external_path(self):
        self.job.update(status="failed", attempts=1)
        auto.atomic(self.job_path, self.job)
        other = self.job_path.with_name("auto-" + "a" * 64 + ".json")
        auto.atomic(other, self.job)
        answer = {"action": "skip", "reason": "Already covered.", "covered_case_keys": [], "specs_json": "[]"}
        with patch.object(auto, "extract", return_value=answer):
            auto.drain(self.corpus, self.job_path)
            self.assertEqual(json.loads(self.job_path.read_text())["status"], "skipped")
            self.assertEqual(json.loads(other.read_text())["status"], "failed")
            self.assertEqual(json.loads(other.read_text())["attempts"], 1)
            outside = self.root / other.name
            auto.atomic(outside, self.job)
            with self.assertRaisesRegex(ValueError, "this corpus inbox"):
                auto.drain(self.corpus, outside)
            self.assertEqual(json.loads(outside.read_text())["attempts"], 1)

    def test_retired_pi_miss_stays_historical_and_new_tasks_still_alert(self):
        self.rows = [
            {"type": "session", "id": SESSION, "version": 3, "cwd": str(self.root)},
            {"type": "message", "id": "u1", "parentId": None, "timestamp": "2099-10-14T12:00:00Z",
             "message": {"role": "user", "content": self.prompt}},
            {"type": "message", "id": "a1", "parentId": "u1", "timestamp": "2099-10-14T12:01:00Z",
             "message": {"role": "assistant", "stopReason": "stop", "content": self.answer}},
        ]
        self.write()
        pi_job = auto.enqueue({"session_id": SESSION, "transcript_path": str(self.source)}, self.corpus)
        job = json.loads(pi_job.read_text())
        job.update(status="skipped", reason="Already covered.", case_keys=[])
        auto.atomic(pi_job, job)
        state, clock = self.monitor()
        entry = self.root / "entry.json"
        auto.atomic(entry, {})
        config = json.loads((state / "config.json").read_text())
        config["entry_install"] = str(entry)
        auto.atomic(state / "config.json", config)
        auto.atomic(state / "install.json", {"recovery_files": {
            str(entry): hashlib.sha256(entry.read_bytes()).hexdigest()}})
        with patch.object(watch, "configuration", return_value=[]), patch.object(watch.time, "time", return_value=clock), \
                patch.object(watch, "notify") as notice:
            watch.check(state)
            self.assertEqual(notice.call_count, 1)
            pi_job.unlink()
            with self.assertRaisesRegex(ValueError, "missing capture assessment"):
                watch.retire_reuse(state, "pi:" + SESSION, "u1", "User requests closure of the historical miss.")
            auto.atomic(pi_job, job)
            first = watch.retire_reuse(state, "pi:" + SESSION, "u1", "User requests closure of the historical miss.")
            self.assertEqual(watch.retire_reuse(state, "pi:" + SESSION, "u1", "Same authorized request."), first)
            notice.reset_mock()
            watch.check(state)
            report = json.loads((state / "state.json").read_text())
            self.assertEqual(report["issues"], [])
            retired = list(report["retired_reuse"].values())
            self.assertEqual(retired[0]["disposition"], "acknowledged_historical_miss")
            self.assertEqual(retired[0]["issue"][0], "pi-reuse")
            # Re-reading native evidence must not resurrect the retired incident.
            for cached in report["files"].values():
                cached["observer_version"] = -1
            auto.atomic(state / "state.json", report)
            watch.check(state)
            notice.assert_not_called()
            self.rows += [
                {"type": "message", "id": "u2", "parentId": "a1", "timestamp": "2099-10-14T12:02:00Z",
                 "message": {"role": "user", "content": "Read-only: " + self.prompt}},
                {"type": "message", "id": "a2", "parentId": "u2", "timestamp": "2099-10-14T12:03:00Z",
                 "message": {"role": "assistant", "stopReason": "stop", "content": self.answer}},
            ]
            self.write()
            os.utime(self.source, (clock, clock))
            watch.check(state)
            watch.check(state)
            self.assertEqual(notice.call_count, 1)
            report = json.loads((state / "state.json").read_text())
            self.assertEqual([(i[0], i[3]) for i in report["issues"]], [("pi-reuse", "u2")])
            # A changed answer is different evidence, not the retired incident.
            self.rows[2]["message"]["content"] = "A changed answer."
            self.write()
            os.utime(self.source, (clock, clock))
            watch.check(state)
            report = json.loads((state / "state.json").read_text())
            self.assertIn(("pi-reuse", "u1"), [(i[0], i[3]) for i in report["issues"]])

    def test_unresolved_failure_cannot_age_into_healthy_or_lose_its_source(self):
        sessions = self.root / "sessions"
        sessions.mkdir()
        source = sessions / "native.jsonl"
        shutil.copyfile(self.source, source)
        at = self.task()["at"]
        os.utime(source, (at, at))
        self.job_path.unlink()
        config = {"data_dir": str(self.corpus), "sessions_dir": str(sessions),
                  "since": "2000-01-01T00:00:00Z", "grace_seconds": 600}
        # OS installation is independently exercised by the real launchd proof.
        with patch.object(watch, "configuration", return_value=[]):
            failed = watch.scan(config, {}, at + 900)
            self.assertEqual([i[0] for i in failed["issues"]], ["capture"])
            later = watch.scan(config, failed, at + 2 * 86400)
            self.assertEqual([i[0] for i in later["issues"]], ["capture"])
            source.unlink()
            with self.assertRaisesRegex(ValueError, "disappeared"):
                watch.scan(config, later, at + 2 * 86400)


if __name__ == "__main__":
    unittest.main()
