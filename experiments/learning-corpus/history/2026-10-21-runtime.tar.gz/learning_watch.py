#!/usr/bin/env python3
"""Independent local evidence check with bounded recovery of known local faults."""

import argparse
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

from learning_auto import atomic, job_identity, restricted, shortlist, stamp, start_drain
from learning_corpus import read_jsonl, transcript

PACKET = "Relevant historical candidate cases from the existing Homebase Learning corpus follow."
OBSERVER_VERSION = 5
WRAPPER = re.compile(r'\AWarning: truncated output \(original token count: \d+\)\nTotal output lines: \d+\n\n')
NOTICE = '''on run argv
display notification (item 2 of argv) with title (item 1 of argv)
end run'''


def seconds(value):
    return datetime.fromisoformat(value.replace("Z", "+00:00")).timestamp()


def delivered_cases(text):
    text = WRAPPER.sub("", text, count=1)
    text = text.removeprefix("<homebase_learning>\n")
    if not text.startswith(PACKET):
        return set()
    result = set()
    for match in re.finditer(r'\{"case_key"\s*:', text):
        try:
            case, _ = json.JSONDecoder().raw_decode(text, match.start())
            # A visible key/revision in a cut object is not a delivered case.
            if all(key in case for key in ("story", "learning", "outcome", "source", "excerpts")) and all(
                    key in case["learning"] for key in ("summary", "applies_when", "does_not_apply_when")):
                result.add((case["case_key"], case["revision"]))
        except (ValueError, KeyError, TypeError):
            continue
    return result


def native_tasks(path, since):
    """Observe actual developer messages before each final, never trust reuse receipts."""
    meta, messages = transcript(path)
    # Native subagents inherit root metadata but have no user chat hooks. Their
    # owning chat remains monitored; do not mistake a child result for a chat.
    if meta.get("thread_source") == "subagent" or isinstance(meta.get("source"), dict) and "subagent" in meta["source"]:
        return []
    session = meta.get("session_id") or meta["id"]
    harness = meta.get("harness", "codex")
    messages = {m["line"]: m for m in messages}
    requests, finals, plans, seen, completed, exposed = {}, {}, {}, set(), {}, {}
    current = None
    for line, row in read_jsonl(path):
        payload = row.get("payload", {})
        if harness == "pi" and row.get("type") == "message" and row.get("message", {}).get("role") == "system":
            sections = row["message"].get("sections", {})
            seen = delivered_cases(sections.get("homebase_learning") or "")
        if harness != "codex" and row.get("type") in ("compaction", "summary"):
            seen.clear()
            seen.update(delivered_cases(row.get("systemMessage", {}).get("sections", {}).get("homebase_learning", "")))
        if row.get("type") == "compacted":
            seen.clear()
            for item in payload.get("replacement_history", []):
                if item.get("type") == "message" and item.get("role") == "developer":
                    seen.update(delivered_cases("\n".join(p.get("text", "") for p in item.get("content", []))))
        if row.get("type") == "event_msg":
            if payload.get("type") == "task_started":
                current = payload["turn_id"]
            elif payload.get("type") == "task_complete":
                completed[payload.get("turn_id", current)] = row.get("timestamp")
        if row.get("type") == "turn_context":
            plans[payload.get("turn_id", current)] = payload.get("collaboration_mode", {}).get("mode") == "plan"
        if row.get("type") == "response_item" and payload.get("type") == "message" and payload.get("role") == "developer":
            text = "\n".join(p.get("text", "") for p in payload.get("content", []))
            seen.update(delivered_cases(text))
        if row.get("type") == "response_item" and (payload.get("role") == "assistant" or
                payload.get("type") in ("reasoning", "function_call", "custom_tool_call")):
            # Delivery already witnessed before model output belongs to this task.
            # Later compaction must not erase it or lend it to another task.
            exposed.setdefault(current, set()).update(seen)
        if harness == "pi" and row.get("type") == "message" and row.get("message", {}).get("role") == "assistant" and row["message"].get("stopReason") in ("toolUse", "stop", "length"):
            exposed.setdefault(current, set()).update(seen)
        message = messages.get(line)
        if not message:
            continue
        turn = message["turn_id"]
        if message["role"] in ("user", "delegate"):
            if not message["text"].startswith(("<external_codex_apps_open_page>", "<skill>")):
                requests[turn] = message
                if harness == "pi":
                    current = turn
        elif message["role"] == "assistant":
            finals[turn] = {**message, "delivered": sorted(seen | exposed.get(turn, set()))}
    for turn, at in completed.items():
        if at and seconds(at) >= since and (turn not in finals or turn not in requests):
            raise ValueError(f"Completed native task cannot be interpreted: {session}/{turn}")
    result = []
    for turn, final in finals.items():
        at = seconds(final["timestamp"])
        if at < since:
            continue
        request = requests.get(turn)
        if not request:
            raise ValueError(f"Native answer has no recognised request: {session}/{turn}")
        result.append({"harness": harness, "session_id": session, "turn_id": turn, "at": at,
                       "request_at": seconds(request["timestamp"]), "prompt": request["text"],
                       "capture_excluded": plans.get(turn, False) or restricted(request["text"], {}),
                       "answer_hash": final["text_sha256"], "delivered": final["delivered"]})
    return result


def task_name(task):
    harness = task.get("harness", "codex")
    return task["session_id"] if harness == "codex" else f"{harness}:{task['session_id']}"


def failure_type(kind):
    return kind.rsplit("-", 1)[-1]


def readable_case(record, text):
    if f"<!-- learning-auto:{record['revision']} -->" in text:
        return True
    # Human reconciliation may replace an auto account. It must still retain
    # this case's source and verbatim witnesses; a bare catalogue key is not enough.
    key = f"Case key: `{record['case_key']}`."
    for section in re.split(r"(?m)^## ", text):
        if key not in section or record["source"]["thread_url"] not in section:
            continue
        visible = re.sub(r"(?m)^> ?", "", section)
        visible = " ".join(visible.split())
        if all(" ".join(e["quote"].split()) in visible for e in record["evidence"].values()):
            return True
    return False


def assess(task, corpus, records, readable, waiting, grace, clock):
    issues = []
    sid, turn = task["session_id"], task["turn_id"]
    harness = task.get("harness", "codex")
    identity = job_identity(sid, turn, task["answer_hash"], harness)
    job_path = corpus / ".runtime/inbox" / f"auto-{identity}.json"
    age = clock - task["at"]
    if not task["capture_excluded"]:
        if not job_path.exists():
            if age >= grace:
                issues.append(("capture", "A completed task has no background assessment.", sid, turn))
        else:
            job = json.loads(job_path.read_text())
            if (job["session_id"], job["turn_id"]) != (sid, turn):
                raise ValueError("Assessment identity disagrees with its native task")
            status = job["status"]
            if status in ("captured", "skipped"):
                if not job.get("reason", "").strip():
                    raise ValueError("Completed assessment has no reason")
                for key in job.get("case_keys", []):
                    matches = [r for r in records if r["case_key"] == key]
                    if status == "captured":
                        matches = [r for r in matches if r["source"]["session_id"] == sid and r["source"]["harness"] == harness and
                                   any(e["turn_id"] == turn for e in r["evidence"].values())]
                    if not matches or (status == "captured" and not any(
                            readable_case(r, readable) and
                            (corpus / r["source"]["transcript_path"]).is_file() for r in matches)):
                        if age >= grace:
                            issues.append(("capture", "An assessment reports a save that is missing or unreadable.", sid, turn))
                if status == "captured" and not job.get("case_keys"):
                    raise ValueError("Captured assessment names no saved cases")
            elif status in ("pending", "processing", "failed"):
                queued = seconds(job["queued_at"])
                # The existing worker sorts job filenames, not arrival times.
                # Allow every other runnable job its full assessment timeout.
                ahead = max(0, len(waiting) - 1)
                if status == "failed" and job.get("attempts", 0) >= 3:
                    ahead = 0
                deadline = grace + 240 * ahead
                if clock - queued >= deadline:
                    issues.append(("capture", "The background assessment queue has exceeded its allowed time.", sid, turn))
            else:
                raise ValueError(f"Unknown assessment status: {status}")
    # Only require a revision that existed when this request arrived. New lessons
    # must never retrospectively create a missing-context fault for old work.
    expected = shortlist(corpus, task["prompt"], before=task["request_at"])
    delivered = set(map(tuple, task["delivered"]))
    reused = bool(expected) and any((c["case_key"], c["revision"]) in delivered for c in expected)
    if expected and not reused and age >= grace:
        issues.append(("reuse", "A task with matching saved cases received no matching case context before its answer.", sid, turn))
    if harness != "codex":
        issues = [(f"{harness}-{kind}", message, task_name(task), turn) for kind, message, _, turn in issues]
    return issues, reused


def configuration(config):
    issues = []
    hooks = json.loads(Path(config["hooks_file"]).read_text()).get("hooks", {})
    for event, action in (("Stop", "stop"), ("UserPromptSubmit", "entry"), ("PreToolUse", "entry")):
        if not any("learning_auto.py " + action in h.get("command", "")
                   for group in hooks.get(event, []) for h in group.get("hooks", [])):
            issues.append(("configuration", f"The {event} learning hook is missing.", None, None))
    install = json.loads(Path(config["entry_install"]).read_text())
    for key in ("launcher", "transport_entry", "transport_runtime", "python", "real_cli"):
        if not Path(install[key]).is_file():
            issues.append(("configuration", f"The installed learning dependency is missing: {key}.", None, None))
    env = subprocess.run(["/bin/launchctl", "getenv", "CODEX_CLI_PATH"], capture_output=True, text=True, timeout=10)
    if env.returncode or env.stdout.strip() != install["launcher"]:
        issues.append(("configuration", "The Codex launch setting no longer selects the learning adapter.", None, None))
    for host in config.get("other_hosts", []):
        harness = host["harness"]
        if harness == "pi":
            if not Path(host["extension"]).is_file():
                issues.append(("pi-configuration", "The Pi personal learning extension is missing.", None, None))
        else:
            raise ValueError("Unsupported monitored host: " + harness)
    return issues


def task_fingerprint(task):
    # Bind closure to native task evidence without retaining the private prompt.
    evidence = {key: task[key] for key in ("harness", "session_id", "turn_id", "request_at", "at", "answer_hash")}
    evidence["prompt_sha256"] = hashlib.sha256(task["prompt"].encode()).hexdigest()
    return hashlib.sha256(json.dumps(evidence, sort_keys=True).encode()).hexdigest()


def scan(config, previous, clock):
    corpus, sessions = Path(config["data_dir"]), Path(config["sessions_dir"])
    if not corpus.is_dir() or not sessions.is_dir():
        raise ValueError("Learning corpus or native session directory is unavailable")
    records = [r for _, r in read_jsonl(corpus / "cases.jsonl")]
    if not records:
        raise ValueError("The previously populated learning corpus is empty")
    readable = (corpus / "cases.md").read_text()
    since = max(seconds(config["since"]), clock - 86400)
    waiting = []
    for path in (corpus / ".runtime/inbox").glob("auto-*.json"):
        job = json.loads(path.read_text())
        if job["status"] in ("pending", "processing") or (job["status"] == "failed" and job.get("attempts", 0) < 3):
            waiting.append(seconds(job["queued_at"]))
    cache = previous.get("files", {})
    unresolved = {(i[2], i[3]) for i in previous.get("issues", []) if failure_type(i[0]) in ("capture", "reuse")}
    for name, prior in cache.items():
        if not Path(name).exists() and any((task_name(t), t["turn_id"]) in unresolved for t in prior["tasks"]):
            raise ValueError("The native source of an unresolved learning failure disappeared")
    files, issues, tasks = {}, [], []
    paths = [(p, since) for p in sessions.rglob("*.jsonl")]
    for host in config.get("other_hosts", []):
        directory = Path(host["sessions_dir"])
        if not directory.is_dir():
            raise ValueError(f"{host['harness']} native session directory is unavailable")
        cutoff = max(seconds(host["since"]), clock - 86400)
        paths.extend((p, cutoff) for p in directory.rglob("*.jsonl"))
    for path, cutoff in paths:
        stat = path.stat()
        prior = cache.get(str(path), {})
        retained = [t for t in prior.get("tasks", []) if (task_name(t), t["turn_id"]) in unresolved]
        if stat.st_mtime < cutoff and not retained:
            continue
        signature = [stat.st_size, stat.st_mtime_ns]
        if prior.get("signature") == signature and prior.get("observer_version") == OBSERVER_VERSION:
            observed = prior["tasks"]
        else:
            observed = native_tasks(path, min([cutoff] + [t["at"] for t in retained]))
        # Prompts only live in transient monitor state. No reasoning/tool output is copied.
        observed = [t for t in observed if t["at"] >= cutoff or (task_name(t), t["turn_id"]) in unresolved]
        files[str(path)] = {"signature": signature, "observer_version": OBSERVER_VERSION, "tasks": observed}
        tasks.extend(observed)
    last_good = {}
    for task in sorted(tasks, key=lambda t: t["at"]):
        failures, reused = assess(task, corpus, records, readable, waiting, config["grace_seconds"], clock)
        issues.extend(failures)
        if reused:
            last_good[task_name(task)] = task["at"]
    # An immutable missing delivery is resolved by a later witnessed delivery in
    # that same chat. Explicit historical retirement below is not recovery.
    times = {(task_name(t), t["turn_id"]): t["at"] for t in tasks}
    issues = [i for i in issues if failure_type(i[0]) != "reuse" or last_good.get(i[2], 0) <= times[(i[2], i[3])]]
    retired = previous.get("retired_reuse", {})
    by_task = {(task_name(t), t["turn_id"]): t for t in tasks}
    issues = [i for i in issues if not (
        failure_type(i[0]) == "reuse" and
        retired.get(issue_id(i), {}).get("disposition") == "acknowledged_historical_miss" and
        retired[issue_id(i)].get("task_fingerprint") == task_fingerprint(by_task[(i[2], i[3])]))]
    issues.extend(configuration(config))
    return {"checked_at": stamp(), "issues": issues, "files": files, "completed_tasks": len(tasks),
            "retired_reuse": retired}


def issue_id(issue):
    return hashlib.sha256(json.dumps(issue).encode()).hexdigest()[:24]


def observed_tasks(report):
    return [task for file in report["files"].values() for task in file["tasks"]]


def verified_install(config, state_dir):
    install = json.loads((state_dir / "install.json").read_text())
    files = install.get("recovery_files", {})
    if not files or str(Path(config["entry_install"])) not in files:
        raise ValueError("The saved recovery installation is unavailable")
    for name, digest in files.items():
        if hashlib.sha256(Path(name).read_bytes()).hexdigest() != digest:
            raise ValueError("Installed learning files changed; an agent must review them")
    return install, json.loads(Path(config["entry_install"]).read_text())


def retire_reuse(state_dir, session, turn, reason):
    """Agent-operated closure of one explicitly acknowledged historical miss."""
    if not reason.strip():
        raise ValueError("Historical retirement requires the user's reason")
    with (state_dir / "lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        config = json.loads((state_dir / "config.json").read_text())
        path = state_dir / "state.json"
        previous = json.loads(path.read_text())
        report = scan(config, previous, time.time())
        verified_install(config, state_dir)
        if any(failure_type(i[0]) == "configuration" for i in report["issues"]):
            raise ValueError("Review the current learning configuration before retiring a miss")
        matches = [i for i in report["issues"] if failure_type(i[0]) == "reuse" and (i[2], i[3]) == (session, turn)]
        if not matches:
            for record in previous.get("retired_reuse", {}).values():
                if tuple(record["issue"][2:]) == (session, turn):
                    return record
            raise ValueError("No active historical reuse miss matches this task")
        if any(failure_type(i[0]) == "capture" and (i[2], i[3]) == (session, turn) for i in report["issues"]):
            raise ValueError("Finish the task's missing capture assessment before retirement")
        issue = matches[0]
        task = next(t for t in observed_tasks(report) if (task_name(t), t["turn_id"]) == (session, turn))
        source = next(name for name, cached in report["files"].items() if task in cached["tasks"])
        record = {"disposition": "acknowledged_historical_miss", "issue": list(issue),
                  "task_fingerprint": task_fingerprint(task), "native_source": source,
                  "retired_at": stamp(), "reason": reason.strip()}
        atomic(path, {**previous, "retired_reuse": {**previous.get("retired_reuse", {}), issue_id(issue): record}})
        return record


def connection_repair(issue, config, state_dir):
    install, entry = verified_install(config, state_dir)
    if issue[0] == "pi-configuration":
        recorded = install["pi_extension"]
        host = next(h for h in config["other_hosts"] if h["harness"] == "pi")
        extension, target = Path(host["extension"]), Path(recorded["target"])
        if (str(extension) != recorded["extension"] or str(target) not in install["recovery_files"] or
                os.path.lexists(extension)):
            raise ValueError("The Pi extension cannot be restored without replacing existing content")
        extension.symlink_to(target)
        return "pi"
    if issue[1] == "The Codex launch setting no longer selects the learning adapter.":
        if entry["launcher"] not in install["recovery_files"]:
            raise ValueError("The recorded Codex launcher is not verified")
        current = subprocess.run(["/bin/launchctl", "getenv", "CODEX_CLI_PATH"], capture_output=True, text=True, timeout=10)
        if current.returncode not in (0, 1) or current.stdout.strip() or current.stderr.strip():
            raise ValueError("The Codex launch setting is unavailable or selects another launcher")
        subprocess.run(["/bin/launchctl", "setenv", "CODEX_CLI_PATH", entry["launcher"]],
                       check=True, capture_output=True, text=True, timeout=10)
        return "codex"
    raise ValueError("This fault requires an agent to review the installation")


def recover(config, state_dir, report, previous, ready, clock):
    """Reuse the worker and installation receipt; never infer a repaired delivery."""
    corpus = Path(config["data_dir"])
    recovery, results, suppressed, errors = {}, [], set(), {}
    old = previous.get("recovery", {})
    # Queue growth can extend the scanner's grace, but cannot turn an unfinished
    # recovery into success or reset the already-started repair deadline.
    for key, repair in old.items():
        if repair["action"] == "resume_capture" and key not in {issue_id(i) for i in report["issues"]}:
            job = json.loads(Path(repair["job_path"]).read_text())
            if job["status"] not in ("captured", "skipped"):
                report["issues"].append(repair["issue"])
    active = {issue_id(i): i for i in report["issues"]}
    tasks = observed_tasks(report)
    for key, repair in old.items():
        if repair["action"] == "restore_connection" and repair["status"] != "failed":
            witnessed = False
            for task in tasks:
                if key in active or task.get("harness", "codex") != repair["harness"] or task["request_at"] < repair["started_at"]:
                    continue
                expected = shortlist(corpus, task["prompt"], before=task["request_at"])
                if any((c["case_key"], c["revision"]) in set(map(tuple, task["delivered"])) for c in expected):
                    witnessed = True
                    break
            if witnessed:
                results.append({**repair, "status": "verified", "verified_at": clock})
            else:
                recovery[key] = repair
        elif key not in active:
            results.append({**repair, "status": "verified" if repair["action"] == "resume_capture" else "cleared",
                            "verified_at": clock})
    changed = False
    for key, issue in active.items():
        if issue[0] not in ready and key not in old:
            continue
        if old.get(key, {}).get("status") == "failed":
            recovery[key] = old[key]
            errors[key] = old[key]["error"]
            continue
        try:
            if failure_type(issue[0]) == "capture":
                task = next(t for t in tasks if (task_name(t), t["turn_id"]) == (issue[2], issue[3]))
                identity = job_identity(task["session_id"], task["turn_id"], task["answer_hash"], task.get("harness", "codex"))
                path = corpus / ".runtime/inbox" / f"auto-{identity}.json"
                job = json.loads(path.read_text())
                if job["status"] not in ("pending", "processing", "failed"):
                    raise ValueError("Saved capture evidence needs an agent to review it")
                if job.get("attempts", 0) >= 3 and job["status"] != "processing":
                    raise ValueError("Capture exhausted its three attempts: " + job.get("error", "assessment failed"))
                repair = old.get(key, {"action": "resume_capture", "started_at": clock,
                                       "task": [issue[2], issue[3]], "status": "retrying",
                                       "job_path": str(path), "issue": issue})
                if clock - repair["started_at"] >= 600:
                    raise ValueError("Capture could not recover within ten minutes; its worker needs inspection")
                recovery[key] = repair
                with (corpus / ".runtime/auto-worker.lock").open("a") as lock:
                    try:
                        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
                    except BlockingIOError:
                        suppressed.add(key)
                        continue
                # The child also acquires this lock nonblocking, closing the race
                # with ordinary task entry without queueing blocked processes.
                start_drain(corpus, path)
                changed = True
                suppressed.add(key)
            elif failure_type(issue[0]) == "configuration":
                if key in old:
                    raise ValueError("The recorded connection repair did not restore the installation")
                recovery[key] = {"action": "restore_connection", "harness": "pi" if issue[0] == "pi-configuration" else "codex",
                                 "started_at": clock, "status": "awaiting_delivery"}
                # Persist intent before changing a connection: a checker crash
                # must not erase the requirement for later actual delivery.
                atomic(state_dir / "state.json", {**previous, **report, "recovery": recovery})
                connection_repair(issue, config, state_dir)
                changed = True
        except (OSError, ValueError, KeyError, TypeError, StopIteration, subprocess.SubprocessError) as error:
            errors[key] = str(error) or "The recorded fault has no safe automatic repair"
            recovery[key] = {**recovery.get(key, old.get(key, {"action": "unrecoverable", "started_at": clock})),
                             "status": "failed", "error": errors[key]}
    if changed:
        report = scan(config, report, clock)
        remaining = {issue_id(i) for i in report["issues"]}
        for key in list(recovery):
            if recovery[key]["action"] == "resume_capture" and key not in remaining:
                job = json.loads(Path(recovery[key]["job_path"]).read_text())
                if job["status"] in ("captured", "skipped"):
                    results.append({**recovery.pop(key), "status": "verified", "verified_at": clock})
                else:
                    report["issues"].append(recovery[key]["issue"])
    report.update(recovery=recovery, repair_results=results, repair_errors=errors)
    return report, suppressed


def notify(kinds, explanations=()):
    body = "Automatic learning could not recover: " + ", ".join(k.replace("-", " ") for k in sorted(kinds)) + ". "
    body += " ".join(dict.fromkeys(explanations))[:600]
    body += " Ask your agent to inspect the local learning checker. Your ordinary work can continue."
    result = subprocess.run(["/usr/bin/osascript", "-e", NOTICE, "Homebase Learning", body],
                            text=True, capture_output=True, timeout=20)
    if result.returncode:
        raise RuntimeError("macOS refused the learning failure notification: " + result.stderr.strip())


def check(state_dir):
    state_dir.mkdir(parents=True, exist_ok=True, mode=0o700)
    with (state_dir / "lock").open("a") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            return
        config = json.loads((state_dir / "config.json").read_text())
        path = state_dir / "state.json"
        previous = json.loads(path.read_text()) if path.exists() else {}
        try:
            report = scan(config, previous, time.time())
        except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError) as error:
            report = {"checked_at": stamp(), "issues": [("check", "Cannot verify learning: " + str(error), None, None)],
                      "files": previous.get("files", {}), "completed_tasks": None,
                      "retired_reuse": previous.get("retired_reuse", {})}
        kinds = {i[0] for i in report["issues"]}
        first_seen = {kind: previous.get("first_seen", {}).get(kind, time.time()) for kind in kinds}
        ready = {kind for kind in kinds if failure_type(kind) in ("capture", "reuse") or
                 time.time() - first_seen[kind] >= config["grace_seconds"]}
        report, suppressed = recover(config, state_dir, report, previous, ready, time.time())
        kinds = {i[0] for i in report["issues"]}
        ready = {i[0] for i in report["issues"] if (i[0] in ready or failure_type(i[0]) in ("capture", "reuse")) and issue_id(i) not in suppressed}
        first_seen = {kind: first_seen.get(kind, time.time()) for kind in kinds}
        notified = set(previous.get("notified", [])) & kinds
        if ready - notified:
            notify(ready, [report["repair_errors"].get(issue_id(i), i[1]) for i in report["issues"] if i[0] in ready])
            notified |= ready
            report["last_notification_accepted_at"] = stamp()
            report["notification_count"] = previous.get("notification_count", 0) + 1
        else:
            report["last_notification_accepted_at"] = previous.get("last_notification_accepted_at")
            report["notification_count"] = previous.get("notification_count", 0)
        report.update(first_seen=first_seen, notified=sorted(notified))
        atomic(path, report)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--state-dir", type=Path, required=True)
    parser.add_argument("--retire-reuse", nargs=2, metavar=("SESSION", "TURN"),
                        help="Agent-operated retirement of one user-acknowledged historical reuse miss")
    parser.add_argument("--reason", help="User authorization and reason for historical retirement")
    args = parser.parse_args()
    if bool(args.retire_reuse) != bool(args.reason):
        parser.error("--retire-reuse and --reason must be supplied together")
    state_dir = args.state_dir.expanduser().resolve()
    if args.retire_reuse:
        record = retire_reuse(state_dir, *args.retire_reuse, args.reason)
        print(json.dumps(record))
    check(state_dir)


if __name__ == "__main__":
    main()
