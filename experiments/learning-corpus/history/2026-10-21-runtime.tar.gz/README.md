# Learning corpus pilot

Candidate cases from native Codex and Pi chats, kept locally with selected source evidence. This pilot tests the data shape, evidence grounding, repeated imports, local search and the Jev request envelope. The CLI makes no model calls. Shared agent instructions now trigger reuse and capture during substantive Homebase work; the agent interprets the source through the existing capture skill. The visible per-turn Stop check was retired after Callum rejected its conversation injection. Its source and bounded trial remain historical evidence. The quiet local replacement is described below; desktop activation is not established by installation alone.

Source and procedure owner: this Agents experiment. The visible data address is `Homebase/Learning/`, owned by the existing KB at `kb-2026/kb-2026/learning/`. Open its `README.md` or `cases.md` in Obsidian. The KB's existing notes-backup branch can archive the corpus; Homebase Git owns only its navigation route.

Native Codex transcripts remain the original history. The corpus preserves only selected visible source messages under `sources/`, with original line and turn references. It contains no tool output or model reasoning. Source paths are relative, so copying the entire corpus preserves its audit path. The schema source lives here; a matching format snapshot travels with the corpus.

## Capture from any project

The shared Homebase learning instruction triggers the installed `capture-learning` skill when consequential learning emerges during normal work, without a user command. `Homebase/Learning/README.md` owns the start/finish procedure and its boundaries. Explicit `$capture-learning` remains available for a requested capture or backfill. The skill reads the source conversation, interprets supported cases, captures their evidence and machine records, and updates the readable cases. Capture stays in `Homebase/Learning` even when the agent is working in Unity Surfaces.

The helper can inspect a source and append a curated selection to the corpus from any current directory:

```sh
python3 /Users/callumflack/Repos/callumflack/homebase/Tooling/agents/experiments/learning-corpus/learning_corpus.py inspect --thread "<thread UUID>"
python3 /Users/callumflack/Repos/callumflack/homebase/Tooling/agents/experiments/learning-corpus/learning_corpus.py capture --thread "<thread UUID>" --spec "<temporary extraction.jsonl>"
```

`inspect` pages eligible visible messages with native provenance. `capture` fills the source path, validates the owned schema and exact quotes, preserves only selected source messages, appends cases and extraction inputs, and audits the result. A later capture from the same thread retains earlier witnesses. Identical captures add no records. The agent still owns interpretation and the readable-page update, preserving human annotations. The returned `readable_update_required` field does not certify that the page has been updated; check it against the latest cases even on a retry.

Temporary capture serialization uses `Learning/.runtime/capture.lock`. It prevents concurrent captures from losing each other's archived evidence or extraction input. It holds no learning content and stays outside Git backups. For an isolated evaluation, use `capture --data-dir <temporary corpus>` and `audit --cases <temporary corpus>/cases.jsonl`.

## Import and reuse

From the Agents Git root:

```sh
python3 experiments/learning-corpus/learning_corpus.py mine \
  --spec "../homebase/Learning/extractions.jsonl"
python3 experiments/learning-corpus/learning_corpus.py audit
python3 experiments/learning-corpus/learning_corpus.py search \
  --query "read edit knowledge deliverable" --limit 2
python3 experiments/learning-corpus/learning_corpus.py request \
  --query "recovery story competing actions" --limit 2 \
  --task "The browser failed to open. The screen offers Open request, Try again and Copy link."
```

Defaults resolve the sibling Homebase checkout and its `Learning/` route. Set `CALLUM_HOMEBASE` for a different Homebase location, or supply `--cases`, `--output` or `--data-dir` explicitly. Corpus source paths stay relative regardless of the navigation route.

Python 3 with its standard library is sufficient. `request` prints an inference request; it neither sends it nor produces a classifier verdict. `jev-latest` is the proposed model alias, to resolve against the provider when actually used.

## The shape

`case.schema.json`, also included in the corpus, describes each `cases.jsonl` row. One case may span several turns. A changed interpretation appends a new revision of the same case; search uses the latest appended revision. Identical revision imports are no-ops.

| Field | Meaning | Who fills it |
| --- | --- | --- |
| `schema_version`, `id`, `revision`, `created_at` | Format, stable case identity, content hash and import time | Script, from the selected case key/source and current clock |
| `source` | Native harness, session, transcript path, original cwd and chat link | Script, from the native session header |
| `evidence` | Exact excerpts with message/turn identity, line, timestamp and text hash | Agent selects excerpts; script locates and verifies them |
| `story` | Goal, situation, needed next step and consequential cues | Agent interpretation, with unknown values allowed |
| `learning` | Candidate distinction, applicability, exceptions, owners and signal | Agent interpretation |
| `outcome` | Partial, reported resolved, user accepted or unresolved; basis and evidence keys | Agent interpretation grounded in the named source excerpts |
| `extraction` | Method and version | Script |

`extractions.jsonl` is the inspectable input the agent produced for this sample. It supplies literal excerpts and the proposed interpretation. `mine` requires every excerpt to occur in exactly one eligible message in its source. It rejects missing or ambiguous quotes before writing the batch. `audit` reopens the source and verifies the quotes, line references, metadata and content hashes.

These checks cannot establish that a selected excerpt supports the interpretation, that the agent found every important case, or that a reported repair worked. The sample marks all generalized lessons `candidate`. It retains partial and unresolved outcomes instead of equating an assistant report with success.

The transcript parser supports the observed Codex and pinned Pi 1.3.0 formats; it is not a stable universal transcript interface. It reads user messages and final assistant messages and skips injected workspace instructions. The first session header owns the log; parent headers copied into forked history cannot replace its identity or turn a subagent into a monitored user chat. Schema drift and malformed JSON fail visibly. Native message IDs differ from the display IDs returned by `read_thread`; evidence uses the native IDs and line/text hashes rather than treating those IDs as aliases.

## Quiet lifecycle integration

The local `learning_auto.py` handlers replace neither the corpus nor the explicit capture procedure. `entry` retrieves existing cases and returns only developer context. `UserPromptSubmit` covers direct requests; `PreToolUse` covers host-delegated tasks before their first tool. A per-chat lock supplies context once per task even when tool callbacks run in parallel. Matching cases retain their evidence, scope and exceptions. This never returns a warning or a blocking continuation decision.

`stop` returns `{}` immediately after queueing a completed task in the existing `.runtime/inbox/`. A detached, serialized worker uses the existing Codex CLI and account for a read-only assessment, following the installed capture-learning evidence rules. This consumes normal Codex usage; it adds no provider, credential, service or schedule. The assessor emits selections only. Python verifies target-turn evidence and exact quotes through the existing importer, completes the readable account while retaining earlier prose and human annotations, audits it, and appends the KB receipt only when something changed. The working chat receives no continuation prompt or assessment response.

Explicit read-only, discussion-only, no-write and no-capture requests bypass writes. Protecting a named README does not prohibit separately authorized Learning capture. A routine or already-covered turn creates no case or KB receipt. Transient jobs carry pending assessment state, not a second knowledge archive; selected message text is removed from completed jobs. Failed jobs remain failed, with bounded retries on later task entry. An exhausted failure reaches the next task as developer context once, so it cannot silently count as successful capture. A queued event or model response is never reported as a saved case without verified persistence and readable completion.

Host-delivered `<codex_delegation>` requests from the two known app chat tools use evidence role `delegate`. They remain distinct from human input and cannot establish human acceptance. Arbitrary tool output, hook continuations and reasoning remain excluded. Old cases remain valid under the extended evidence vocabulary; their hashes are retained.

Install with `python3 experiments/learning-corpus/learning_auto.py install`, then review and trust the exact definitions through Codex's supported `/hooks` interface. Existing unrelated hooks are preserved. The retired `learning_finish.py` blocking installer remains disabled. Existing desktop sessions must load the new trusted configuration. Callum completed the one agreed setup restart. An ordinary existing-chat correction then saved a source-backed case, and another existing chat received and applied it during an ordinary source-check request. The original short-answer retrieval stage failed because a host-delivered request used no tools and fired no prompt-entry event. The PreToolUse fallback cannot cover those turns. The Learning evaluation records both results; neither installation nor a CLI pass substitutes for desktop evidence.

`python3 experiments/learning-corpus/learning_auto.py status` is a diagnostic view of source-attributed pending, skipped, captured and failed jobs. No routine user command is required. `python3 -B -m unittest discover -s experiments/learning-corpus -p 'test_*.py' -v` checks the capture, quiet-context, no-write and retired-handler boundaries. Native dispatch, absence of visible continuation prompts, useful capture and later reuse require the ordinary-task proof linked from Homebase Learning.

Official wire contract: [Codex hooks](https://learn.chatgpt.com/docs/hooks). `additionalContext` supplies developer context; blocking Stop decisions create user-prompt continuations. This implementation uses the former and returns no blocking Stop decision.

## No-tool delegated entry adapter

`learning_proxy.mjs`, running on the app-owned signed Node runtime, addresses the case that recipient hooks cannot cover: a known app-delegated request answered without tools. The local desktop launch wrapper starts the same bundled CLI and stdio app-server. Before forwarding its known `codex_app` delegated `turn/start`, it selects cases through the existing helper and sends the documented `thread/inject_items` developer-context request to that same server. It waits for acknowledgment, hides its internal response, then forwards the original request unchanged. The entry recognizes documented global configuration and feature options before the command and preserves the full original argument vector. Other CLI commands, direct inputs including explicit null tool output, unrelated tool outputs and native notifications pass through. A failed append records failure and preserves the original task; it never creates a delivered receipt.

The short-lived `learning_entry.py` helper uses the existing case renderer and advisory evidence boundaries. Python is outside the native server's ancestry and is no longer the persistent launch process. The existing reuse state suppresses a second recipient PreToolUse packet. Read-only requests can receive case context without corpus or runtime writes. Capture still belongs to the installed Stop path and existing assessor/importer. There is no generated user turn, assistant reply or capture instruction in the ordinary request.

On this Mac, `~/.local/bin/codex-quiet-learning` selects the adapter with the desktop's existing `CODEX_CLI_PATH` launch setting. A login-only `com.callumflack.codex-learning-env` LaunchAgent restores the environment after login; it has no interval. `.runtime/entry-install.json` preserves the previous setting and exact created files. The wrapper passes version and other CLI commands to the bundled binary. No vendor application file, account, model, hook definition or trust record changes. The first restart inherited this entry point, but the wrapper bypassed the adapter because the desktop placed `-c` settings before `app-server`. The next Python wrapper started but broke built-in chat-tool authorization: native peer ancestry includes a Python executable with no signing team. The replacement uses Codex's signed Node runtime without changing authorization. The 17 October restart replaced that Python process with the signed-runtime transport and restored native chat-tool availability.

The Learning evaluation's `no-tool-entry/` packet owns native fixture results, both failed desktop startups, the frozen retry request and activation state. The first native attempt lacked a delivery receipt and lost its temporary diagnostic; its cause remains unknown. The first desktop attempt answered without tools but had no case packet. The second loaded Python but could not expose the built-in chat-control tools, so no target request was sent. All 23 owner checks now pass on the signed transport. The installed launcher passes normal discovery of 57 chat-control tools and the real ephemeral no-tool case task with the exact desktop arguments. The 17 October existing-desktop witness also passed. The approved ordinary request received the exact previously auto-saved case revision before a zero-tool answer, with no generated learning user continuation. Native chat controls worked; the completion assessor skipped a duplicate. The capture witness is from 16 October, and its portable source audit passes. The evaluation preserves both failed trials and the actual result without claiming universal relevance or a causal improvement in answers.

To roll back, an agent first restores the installation receipt's prior launch environment and unloads only this named login entry. Quit and reopen the desktop before removing the recorded launcher, so no cached client points at a deleted executable. Existing native chats and corpus records stay at their owners. Callum needs no recurring command.

## Independent quiet checker

`learning_watch.sh` and `learning_watch.py` run separately from Codex under the local `com.callumflack.learning-check` LaunchAgent. The job runs at login and every 300 seconds. Its scan makes no model calls and creates no chat messages. Bounded recovery can resume the existing capture worker, which uses the already-authorized Codex assessor and importer, or restore a missing recorded connection after matching installation fingerprints. Configuration, recovery status and bounded transient activity state live in `~/Library/Application Support/Callum/Learning Check/`; `install.json` records this installation and its `recovery_files` fingerprints. There are no recurring operator commands.

The checker parses native completed tasks and actual developer case packets, compares capture identities against the existing inbox, and requires reported captures to exist with readable accounts and preserved source files. A skipped assessment with a reason is healthy. A reuse receipt is insufficient. Existing `shortlist`, `search` and `latest` accept an optional timestamp cutoff so the checker can reconstruct the shortlist available when the request arrived, without changing normal live retrieval. The parser accepts the observed native truncation wrapper, but counts only complete decodable case objects. A bare visible key/revision or a delivery receipt is insufficient. It retains actual case exposure before model output for that task even if compaction happens later. Compaction clears availability for subsequent tasks unless its native replacement history explicitly retains the case. An observer-version change forces cached source observations to be parsed again; old faults are not cleared by editing monitor state.

Missing assessment or matching context receives 600 seconds of grace. A queued assessment also receives the existing 240-second assessor timeout for every other runnable job; the worker does not sort by arrival time. Persistent unreadable-source or configuration faults warn after 600 seconds. Each active failure type warns once, through the existing Script Editor macOS notification channel with title `Homebase Learning`. Healthy, idle, duplicate and restored checks remain silent. Refused notification commands do not acknowledge the incident. The shell also warns once if Python cannot start or run the checker. Unresolved tasks survive the ordinary one-day activity retention window. Automatic reuse recovery requires a later witnessed matching delivery in that chat. With explicit user authorization, an agent may instead retire one historical reuse miss using `--retire-reuse SESSION TURN --reason TEXT` on the existing checker. This preserves an `acknowledged_historical_miss` record in its existing state with the original issue, source path, native task fingerprint, reason and retirement time; it never claims delivery or recovery. Retirement requires verified installation files, current configuration and no outstanding capture fault. It survives cache reparsing, applies only to unchanged evidence for that exact task, and leaves new tasks, capture faults and configuration faults eligible for alerts. No operator command or schedule is added.

Before alerting, the checker resumes an overdue existing inbox job within its original three-attempt budget. The worker can select one named job and takes its normal lock nonblocking for recovery, so another active worker is left alone and unrelated jobs are not drained. Recovery has a ten-minute deadline after detection; it never resets the job budget or repeatedly restarts an exhausted incident. A captured or legitimately skipped assessment must pass the same source/readable checks before recovery counts. Queue growth does not establish success or reset this repair deadline.

The other permitted repairs are restoring an absent Pi extension symlink to its recorded target and restoring an unset `CODEX_CLI_PATH` to its recorded launcher. Every pinned dependency must still match; existing content, a different launcher, changed installation files, missing native evidence, missing trusted hooks and source/code defects require attention. The checker records restoration intent before mutation and keeps reuse `awaiting_delivery` until a later ordinary task in that harness actually receives a matching case before answering. A restored setting alone is insufficient, and no past missed answer is rewritten. It starts no proof chat, changes no hook trust and never restarts an app automatically. Successful recovery stays silent; an unsupported, failed or exhausted incident alerts once through the existing channel. The shell fallback still handles an unavailable Python checker.

The KB-owned `Homebase/Learning/evaluations/2026-10-20-checker-recovery/` packet records a silently restored disposable Pi link, one actual macOS alert for an exhausted copied capture job, quiet repeats, and unchanged live scheduling. Owner tests exercise actual importer/readable completion behind a substituted assessor, retry exhaustion, busy-worker limits, file fingerprints, ownership preservation and native delivery confirmation. The fault proof makes no model calls; it is not new ordinary-task capture or semantic reuse proof.

The job is installed at `~/Library/LaunchAgents/com.callumflack.learning-check.plist`. An agent can remove it by unloading only that named user LaunchAgent and removing its recorded files; no Codex restart or capture-hook change is needed. `test_watch.py` owns the evidence-boundary regressions. The KB-owned `Homebase/Learning/evaluations/2026-10-20-quiet-checker/` packet owns the real-record fault, notification, duplicate and recovery proof. No proof-only job remains installed.

The native source/delivery checker covers Codex and the installed Pi personal extension. It reads actual Pi `system.sections.homebase_learning` before the final answer, uses host-scoped capture identities, and distinguishes native subagents from user chats. A human-reconciled readable case can replace an automatic marker only while retaining its case key, source link and exact evidence. Claude Desktop Chat remains unchanged and unsupported for automatic lifecycle capture. The checker cannot grade the semantics of a skip or case, prove better answers, guarantee every unknown future schema is recognised, run while the Mac is off, or report its own LaunchAgent being unloaded. macOS notification preferences still govern presentation.

## Pi personal extension

Pi 1.3.0 loads `~/.pi/agent/extensions/homebase-learning.ts`, a link to this owner's `pi-learning.ts`. Its native `before_agent_start` event supplies a bounded case packet as a system section; `agent_settled` queues the completed native session through `learning_hosts.py`. It adds no user message, continuation, model tool or new schedule. Fresh Pi sessions load it through personal extension discovery. `--no-extensions` explicitly bypasses it and will be reported as missing work after a monitored task. Explicit no-write and discussion-only requests still bypass capture.

The source adapter preserves actual Pi session/message/parent/turn identity, final visible text and hashes, while excluding thinking, tool messages and errored or aborted replies. Selected sources are `sources/pi-<session UUID>.jsonl`; they never receive a Codex chat URI. Native Codex archive addresses, record hashes and capture identities remain compatible. The shared read-only capture assessor still uses the existing Codex CLI/account, including for Pi work. This is shared local storage, not an entirely Pi-only runtime.

The existing search owner now ranks whole words in content using term frequency, corpus rarity and document length, rather than substrings in serialized field names. The shared Codex/Pi renderer fits whole candidate records into 6,000 UTF-8 bytes. It keeps the goal, full learning with scope and exceptions, outcome, source identity and a selected excerpt; it omits whole lower-ranked candidates rather than cutting those fields. Preparation receipts name only the selected keys/revisions. A candidate whose scope cannot fit fails explicitly before being acknowledged. This repair followed a real failed cross-session retrieval; a plausible answer did not count as reuse. The frozen retry received the exact newly saved revision in its native system section before a no-tool answer. The KB proof records initial failures, default-model repair, actual capture, successful reuse and isolated copied-record checker faults.

On this Mac, Pi's old `openai/gpt-5.5` default was rejected by the existing ChatGPT account. The default was restored to `openai/gpt-6.1-sol`, which the previous real Pi session and both passing tasks used. Provider and credentials did not change. The existing checker config now includes Pi's session directory and extension path; its admission cutoff starts with the repaired native setup. Earlier development misses remain in the evaluation rather than being presented as healthy tasks. No additional LaunchAgent is installed.

Claude means the ordinary Desktop Chat tab in this request. [Anthropic documents that hooks do not run in chat](https://support.claude.com/en/articles/13837440-use-plugins-in-claude). Local MCP tools are available, but availability does not prove automatic invocation, complete transcript access or after-answer capture. Callum explicitly chose to leave Claude unchanged instead of installing that lower-guarantee fallback. Temporary Code hook registrations and unused Code parsing were removed; the existing tldraw hook remains. No Chat connector, project instruction, account-memory setting or app patch was added.

## Wrapped context and compaction repair

The two 20 October reuse warnings were false alarms at the observation boundary. Native developer records showed full relevant cases before model output, but Codex wrapped the oversized hook output in a truncation notice; the checker recognised only the bare prefix. Later compaction also erased the checker's global delivery set, even after the model had already received context in that task. The parser now recognises that native wrapper, ignores incomplete case fragments, and retains witnessed model exposure within its owning task. It does not transfer that exposure to later tasks or accept a packet arriving after an answer. Versioned cached observations are re-read from native source after this repair.

All entry routes now use `candidate_packet` for bounded context and accurate selected-case metadata. This replaces the duplicated Pi compaction path and the previous unbounded Codex renderer. The running native launcher and hooks did not change; these Python helpers load afresh on each call, so activation required no app restart. Ordinary requests in the two affected chats received complete 5,222-byte and 4,622-byte packets before their answers. The recovery-chat request completed without tools. The request to this active chat was reentrant and received a brief commentary answer before further tools; it is not claimed as a separate completed no-tool task. `Homebase/Learning/evaluations/2026-10-20-codex-reuse-repair/` owns the native lines, scope/exception comparison, negative controls and live checker result.

## Retired visible finish check

Callum rejected the Stop hook because it inserted a long learning-review prompt into ordinary conversations whenever a turn had no review. It required bookkeeping even for routine work, making the proposed automation another visible interruption. A passing fresh CLI capture did not establish an acceptable desktop experience or reliable capture in existing chats.

The learning handler has been removed from `~/.codex/hooks.json`, preserving all other hooks. Its `stop` command returns `{}` without reading a transcript or writing review state, so an already-loaded registration is also inert. `install` rejects reinstallation. Old explicit `review` commands remain readable and valid for compatibility with already-injected historical instructions; they are not required for new tasks.

The source adapter still excludes historical `<hook_prompt>` messages from user evidence. Existing cases, source records, readable pages and the normal capture-learning procedure remain intact. The active task agent retains its capture responsibility. The quiet replacement below is a separate implementation authorized after that retirement. The later quiet replacement has bounded existing-desktop capture and cross-chat delivery evidence. Its no-tool app-delegation retrieval gap remains explicit in the Learning evaluation.

The existing Learning evaluation preserves the passing bounded CLI trial, failed existing-chat test, supported reload investigation and subsequent user rejection. Those trials are historical evidence, not an accepted current implementation.

## Downhill use

Local word matching currently supplies a small shortlist. The proposed Jev request compares those cases with current task evidence and asks, per case, whether the distinction is relevant, irrelevant, missing context or contradicted. It contains `state` plus typed `questions`, without training labels. The returned decision would select context or prompt investigation; it would not promote a historical candidate into current policy or authorize an action.

The request is only as useful as its current-work evidence. UI arrangement, actions and their actual effects must be described or observed; prose about the UI alone cannot establish visual correctness. Cases can preserve artifact references and later receive actual witnesses without fabricating them.

Keep future Jev judgments in their own record with case revisions, task evidence, question version and model identity. Do not overwrite the source case with the classifier's answer. Jev receives selected context through its API; the archive and retrieval stay local.

## Verify capture

From the Agents Git root:

```sh
python3 -B -m unittest discover -s experiments/learning-corpus -p test_capture.py -v
```

These CLI tests exercise portable evidence, repeated capture, retaining earlier witnesses and revisions, and rejection before durable writes. A forward test on 14 October 2026 used an independent agent and the installed skill from Unity Surfaces. It captured one previously unmined typography case into a temporary copy, updated its readable page and added zero records on retry. The reviewed candidate then entered the live corpus. This proves an explicit capture path; it does not establish automatic mining or better subsequent decisions.

## Prior art

- [Pi session format](https://github.com/badlogic/pi-mono/blob/main/packages/coding-agent/docs/session-format.md): retain existing session JSONL and precise entry provenance; keep derived data separate.
- [Claude-Mem hook spool](https://github.com/thedotmack/claude-mem/blob/main/src/shared/hook-spool.ts): deterministic event identity and atomic per-event capture before expensive interpretation.
- [Jared Palmer's Kev format](https://github.com/jaredpalmer/kev/blob/main/skills/kev-finetune/references/data-format.md): separate state from explicit typed questions. This pilot borrows the inference envelope and excludes training machinery.
- [TypeSafe API](https://docs.typesafe.ai/api): Jev classifies supplied state and questions; a local file does not become persistent memory inside the model.
- [Codex hooks](https://learn.chatgpt.com/docs/hooks): Stop payload, JSON output, native transcript-format limitation and mandatory trust review.

These sources were inspected, not installed or run. The earlier pilot did not establish automatic extraction. The quiet integration now has bounded native CLI evidence; classifier accuracy, reliable existing-desktop activation, cross-project transfer and fewer human corrections remain separate proof obligations. The next meaningful result is a fresh comparable task using the cases before Callum repeats the correction, alongside a similar task where the case should not apply.
