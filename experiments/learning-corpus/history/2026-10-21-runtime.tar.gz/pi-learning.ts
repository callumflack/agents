import { spawnSync } from "node:child_process";
import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";

const python = "/opt/homebrew/opt/python@3.14/bin/python3.14";
const helper = "/Users/callumflack/Repos/callumflack/agents/experiments/learning-corpus/learning_hosts.py";

type BridgeRequest =
  | { action: "entry"; prompt: string }
  | { action: "stop"; session_id: string; transcript_path: string };

function invoke(request: BridgeRequest): string | undefined {
  const { action, ...input } = request;
  const result = spawnSync(python, ["-B", helper, action, "pi"], {
    input: JSON.stringify(input), encoding: "utf8", timeout: 10000, maxBuffer: 4 * 1024 * 1024,
  });
  if (result.status !== 0) throw new Error("Homebase Learning helper could not run");
  const value: unknown = JSON.parse(result.stdout);
  if (typeof value !== "object" || value === null) throw new Error("Invalid Homebase Learning response");
  if (!("context" in value)) return undefined;
  if (typeof value.context !== "string") throw new Error("Invalid Homebase Learning context");
  return value.context;
}

export default function (pi: ExtensionAPI) {
  if (process.env.CALLUM_LEARNING_WORKER) return;
  pi.on("before_agent_start", (event) => {
    if (event.messageType !== "user") return;
    const context = invoke({ action: "entry", prompt: event.prompt });
    if (context) event.systemPromptOptions.sections.homebase_learning = context;
    else delete event.systemPromptOptions.sections.homebase_learning;
  });
  pi.on("agent_settled", (event, ctx) => {
    if (event.aborted) return;
    const source = ctx.sessionManager.getSessionFile();
    if (source) invoke({ action: "stop", session_id: ctx.sessionManager.getSessionId(), transcript_path: source });
  });
}
