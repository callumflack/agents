"""The app-server boundary must preload cases without a tool or user continuation."""
import json
import os
import subprocess
from pathlib import Path
import sys
import tempfile
import unittest

import test_auto


BACKEND = '''import json,sys
history = []
for line in sys.stdin:
    r=json.loads(line)
    if r['method']=='thread/inject_items':
        history.extend(r['params']['items'])
        result={}
    elif r['method']=='turn/start':
        result={'turn':{'id':'target-turn','items':[], 'context':history, 'received':r['params']}}
    else:
        result={'echo':r}
    print(json.dumps({'id':r['id'],'result':result}),flush=True)
'''


class ProxyTests(unittest.TestCase):
    def setUp(self):
        self.fixture = test_auto.QuietTests()
        self.fixture.setUp()
        self.addCleanup(self.fixture.doCleanups)
        self.fixture.corpus.joinpath('cases.md').write_text('# Learning cases\n\n')
        import learning_auto
        learning_auto.apply_result(self.fixture.job(), self.fixture.assessment(), self.fixture.corpus)
        self.backend = self.fixture.root / 'backend.py'
        self.backend.write_text('#!' + sys.executable + '\n' + BACKEND)
        self.backend.chmod(0o755)

    def exchange(self, requests, arguments=None):
        entry = (Path(__file__).resolve().parent / 'learning_proxy.mjs').as_uri()
        command = [str(self.backend), *(arguments or ['app-server'])]
        harness = 'import {run} from ' + json.dumps(entry) + '; process.exitCode=await run(JSON.parse(process.argv[1]));'
        result = subprocess.run(['/Applications/ChatGPT.app/Contents/Resources/cua_node/bin/node',
            '--input-type=module', '-e', harness, json.dumps(command)],
            input=''.join(json.dumps(r)+'\n' for r in requests), text=True, capture_output=True,
            timeout=30, env={**os.environ, 'CALLUM_HOMEBASE':str(self.fixture.root)})
        self.assertEqual(result.returncode, 0, result.stderr)
        return [json.loads(line) for line in result.stdout.splitlines()]

    def delegated(self, identity=7):
        return {'id':identity,'method':'turn/start','params':{'threadId':'existing-chat','input':[],
            'toolOutput':{'namespace':'codex_app','name':'send_message_to_thread',
                          'output':'<codex_delegation>\n<input>Explain upload completion and a saved local file.</input>\n</codex_delegation>'}}}

    def test_delegated_no_tool_turn_receives_case_before_generation(self):
        request = self.delegated()
        responses = self.exchange([request])
        self.assertEqual([r['id'] for r in responses], [7])
        result = responses[0]['result']['turn']
        self.assertEqual(result['received'], request['params'])
        self.assertEqual(result['items'], [])
        self.assertEqual(len(result['context']), 1)
        item = result['context'][0]
        self.assertEqual(item['role'], 'developer')
        text = item['content'][0]['text']
        self.assertIn('saved-before-uploaded', text)
        self.assertIn('saved locally', text)
        import learning_auto
        self.assertEqual(learning_auto.context({
            'hook_event_name':'PreToolUse', 'session_id':'existing-chat',
            'turn_id':'target-turn', 'prompt':request['params']['toolOutput']['output'],
        }, self.fixture.corpus), {})

    def test_cli_entry_accepts_desktop_global_options_without_changing_arguments(self):
        self.backend.write_text('#!' + sys.executable + '\n' + BACKEND.replace(
            "'received':r['params']", "'received':r['params'], 'cli_args':sys.argv[1:]"))
        variants = [
            (['-c', 'features.code_mode_host=true', 'app-server', '--analytics-default-enabled',
              '-c', 'plugins.codex-app-tools@openai-bundled.mcp_servers.codex_app.enabled=true',
              '-c', 'plugins.code-review@openai-bundled.mcp_servers.code-review.enabled=true'], True),
            (['--config=features.code_mode_host=true', 'app-server', '--listen', 'stdio://'], True),
            (['--enable', 'code_mode_host', 'app-server'], True),
            (['-c', 'value="app-server"', 'exec', 'app-server'], False),
            (['-c', 'features.code_mode_host=true', 'app-server', 'daemon', 'version'], False),
            (['--version'], False),
        ]
        request = self.delegated()
        for arguments, expected_context in variants:
            with self.subTest(arguments=arguments):
                result = self.exchange([request], arguments)[0]['result']['turn']
                self.assertEqual(result['cli_args'], arguments)
                self.assertEqual(result['received'], request['params'])
                self.assertEqual(bool(result['context']), expected_context)

    def test_direct_input_and_unrelated_tool_output_are_unchanged(self):
        direct={'id':2,'method':'turn/start','params':{'threadId':'existing-chat','input':[{'type':'text','text':'Hello'}],'toolOutput':None}}
        other=self.delegated(3);other['params']['toolOutput']['namespace']='other'
        replies=self.exchange([direct,other])
        self.assertEqual([r['id'] for r in replies],[2,3])
        for response,original in zip(replies,[direct,other]):
            self.assertEqual(response['result']['turn']['received'],original['params'])
            self.assertEqual(response['result']['turn']['context'],[])


    def test_failed_context_append_keeps_request_and_records_failure(self):
        self.backend.write_text('#!' + sys.executable + '\n' + BACKEND.replace("history.extend(r['params']['items'])\n        result={}",
            "print(json.dumps({'id':r['id'],'error':{'code':-1,'message':'unsupported'}}),flush=True)\n        continue"))
        request=self.delegated()
        replies=self.exchange([request])
        self.assertEqual([r['id'] for r in replies],[7])
        self.assertEqual(replies[0]['result']['turn']['received'],request['params'])
        self.assertEqual(replies[0]['result']['turn']['context'],[])
        failure=json.loads((self.fixture.corpus/'.runtime/auto-error.json').read_text())
        self.assertEqual(failure['command'],'preload')
        self.assertIn('unsupported',failure['error'])
        self.assertFalse((self.fixture.corpus/'.runtime/reuse/existing-chat.json').exists())

    def test_read_only_request_receives_context_without_corpus_writes(self):
        before={str(p.relative_to(self.fixture.corpus)):p.read_bytes() for p in self.fixture.corpus.rglob('*') if p.is_file()}
        request=self.delegated()
        request['params']['toolOutput']['output']=request['params']['toolOutput']['output'].replace('<input>','<input>Read-only: ')
        response=self.exchange([request])[0]
        self.assertEqual(len(response['result']['turn']['context']),1)
        after={str(p.relative_to(self.fixture.corpus)):p.read_bytes() for p in self.fixture.corpus.rglob('*') if p.is_file()}
        self.assertEqual(before,after)

    def test_native_notifications_pass_through_while_internal_ack_is_hidden(self):
        self.backend.write_text('#!' + sys.executable + '\n' + BACKEND.replace("history.extend(r['params']['items'])",
            "print(json.dumps({'method':'native-notification','params':{'value':1}}),flush=True)\n        history.extend(r['params']['items'])"))
        replies=self.exchange([self.delegated()])
        self.assertEqual(replies[0],{'method':'native-notification','params':{'value':1}})
        self.assertEqual(replies[1]['id'],7)
        self.assertEqual(len(replies),2)


if __name__=='__main__':
    unittest.main()
